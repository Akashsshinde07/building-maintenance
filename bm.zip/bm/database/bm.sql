-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2023 at 09:32 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bm`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_event`
--

CREATE TABLE `add_event` (
  `event_title` varchar(50) NOT NULL,
  `event_description` varchar(100) NOT NULL,
  `event_status` varchar(100) NOT NULL,
  `created_date` varchar(50) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `add_flat`
--

CREATE TABLE `add_flat` (
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `apartment_name` varchar(100) NOT NULL,
  `e_mail` varchar(100) NOT NULL,
  `mob_number` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pin_code` int(6) NOT NULL,
  `flat_user` varchar(20) DEFAULT NULL,
  `flats` varchar(50) NOT NULL,
  `m_amount` varchar(50) NOT NULL,
  `flat_floor` int(50) NOT NULL,
  `flat_wing` varchar(50) NOT NULL,
  `flat_number` varchar(50) NOT NULL,
  `pre_reading` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_flat`
--

INSERT INTO `add_flat` (`first_name`, `last_name`, `apartment_name`, `e_mail`, `mob_number`, `address`, `city`, `pin_code`, `flat_user`, `flats`, `m_amount`, `flat_floor`, `flat_wing`, `flat_number`, `pre_reading`, `middle_name`, `id`) VALUES
('Suhas & Dilip Dashrath Khade', '', 'vidya corner', 'shreyasfoto@gmail.com', '7588594988', 'Rui Baramati 413133', '', 0, 'Owner', 'Shop', '204.23', 0, '', 'G31', '', '', 2),
('Doiphode & Associate ', '', 'vidya corner', 'nittendoiphode@ymail.com', '9371764761', 'MIDC Baramati.Jawaharnagar,Indapur Rd. Baramati.', '', 0, 'Owner', 'Office', '1554.44', 0, '', 'F12-13-14-15-16-17', '', '', 3),
('Aruna sanjay khade ', '', 'vidya corner', 'sushantkhade9999@gmail.com', '9890919000', 'Kavi moropant sosayti bhigvan rod Baramati ', '', 0, 'Owner', 'Shop', '100.88', 0, '', 'G45', '', '', 4),
('SHIVLEELA SURYAKANTH REDDY', '', 'vidya corner', 'reddysr@venkateshwarsales.com', '9850539300', 'Sai nagar Rui ', '', 0, 'Owner', 'Shop', '744.05', 0, '', 'B31-32-29 ', '', '', 5),
('B.M.Bhosale', '', 'vidya corner', 'bmbhosale99@gmail.com', '9823822211', 'Kalyani Corner Baramati', '', 0, 'Owner', 'Office', '533.70', 0, '', 'T23', '', '', 6),
('Firoj Iqbalbhai Shaikh', '', 'vidya corner', 'firojshaikh153@gmail.com', '9921434303', 'Ekta Nagar kasba Baramati', '', 0, 'Renter', 'Shop', '0', 0, '', 'G15', '', '', 7),
('Devidas sakharam karande', '', 'vidya corner', 'digitalpawan5@gmail.com', '98228 7953', 'Green Park. Baramati. Rui', '', 0, 'Owner', 'Shop', '0', 0, '', 'G55', '', '', 8),
('Tararam B devasi ', '', 'vidya corner', 'tararamdewasi3@gmail.com', '8928422888', 'Vidha कॉर्नsuper  market MIDC baramti ', '', 0, 'Renter', 'Shop', '0', 0, '', 'G18', '', '', 9),
('Ashok Vitthal Ingale ', '', 'vidya corner', 'ashokingale1946@gmail.com', '9527379111', 'Ashok Vitthal Ingale  at post Bagerangwadi  laty Tal Baramati pune', '', 0, 'Owner', 'Shop', '269.00', 0, '', 'B27-28', '', '', 10),
('Kalpana Balu Adsul ', '', 'vidya corner', 'agawaneparashuram0@gmail.com', '9860687819', 'Baramati', '', 0, 'Owner', 'Shop', '103.19', 0, '', 'G42', '', '', 11),
('Amit Deepak shah', '', 'vidya corner', 'amit.sakalp@gmail.com', '98604 3900', 'Sakalp printing press indapur road Baramati ', '', 0, 'Owner', '1BHK', '390.66', 0, '', 'G08-09-10', '', '', 12),
('Santosh Mahadeo Zambare ', '', 'vidya corner', 'santoshzambare22@gmail.com', '9423240339', 'Zambare Bunglow, B G Ghare path ,Vijay Nagar, Baramati ', '', 0, 'Owner', '1BHK', '233.54', 0, '', 'G16-17', '', '', 13),
('Sunil Hukumchand Shah', '', 'vidya corner', 'drsunilshah09@gmail.com', '9822979426', 'YASHSHREE NUSRING HOME, ASHOKNAGAR, BEHIND SBI, BARAMATI', '', 0, 'Owner', '1BHK', '418.6', 0, '', 'G27-28-29-30', '', '', 14),
('Shahaji Tukaram Rananavare', '', 'vidya corner', 'shahajir60@gmail.com', '9850950498', 'R-60,Giridhar bunglow,Suyashbagar corner,midc Baramati, Dist-Pune-413133', '', 0, 'Renter', '1BHK', '141.49', 0, '', 'G19', '', '', 15),
('Sanket Dangade', '', 'vidya corner', 'sanketonline42@gmail.com', '7057022142', 'Vidyanagari super market MIDC chowk Baramati', '', 0, 'Renter', '1BHK', '0', 0, '', 'B34', '', '', 16),
('Vinod Vikas kothari', '', 'vidya corner', 'VVKOTHARI1008@GMAIL.COM', '9970054646', 'A/P. MALEGAON KD, TAL-BARAMATI, DIST-PUNE', '', 0, 'Renter', '1BHK', '0', 0, '', '18', '', '', 17),
('MOIZ S QUAMARI(Chashma Ghar)', '', 'vidya corner', 'qamaritaher@gmail.com', '9421006071', 'Jalochi baramati', '', 0, 'Renter', '1BHK', '334.36', 0, '', 'G03-04', '', '', 18),
('Santosh Ramdas Ghadge', '', 'vidya corner', 'santoshramdasg@gmail.com', '7304111123', 'pencil chouk midc', '', 0, 'Owner', '1BHK', '122.02', 0, '', 'B5', '', '', 19),
('SURAJ PRAMOD MANDHARE', '', 'vidya corner', 'shreexerox96@gmail.com', '9764400505', 'SHREE XEROX', '', 0, 'Owner', '1BHK', '0', 0, '', 'B07', '', '', 20),
('Swamirao Virbhadra Chakre', '', 'vidya corner', 'Swamirao.v.chakre@gmail.com', '9970831353', 'Burud galli baramati', '', 0, 'Renter', '1BHK', '0', 0, '', 'G46', '', '', 21),
('Sudhir Mukund Bhoite', '', 'vidya corner', 'dr.shree2010@rediffmail.com', '9423756364', 'Shop No. 01, First Floor, Vidya Corner Super Market, Pencil Chowk, Midc, Baramati, Dist - Pune, Pin ', '', 0, 'Owner', '1BHK', '0', 0, '', 'F01', '', '', 22),
('Deokate Vaishali Hanumantrao', '', 'vidya corner', 'hanumantdeokate149@gmail.com', '7588955775', 'Samruddhi App. Flat No,05 R-20, Residency Zone,Sahkarnagar Midc Chouk Vidyanagari Baramati', '', 0, 'ower', '1BHK', '137.94', 0, '', 'G21', '', '', 23),
('Minal Holkar', '', 'vidya corner', 'Holkarsurendra@gmail.com', '9970840123', 'Avachat estate patas road. Baramati', '', 0, 'Owner', '1BHK', '0', 0, '', ' G38', '', '', 24),
('Vilite Multimedia Pvt. Ltd.', '', 'vidya corner', 'vilitem@gmail.com', '8380031501', 'Office No.8 & 9, P-15, Vidyacorner Super Market, Pencil Chowk, MIDC, Baramati, Pune - 413102', '', 0, 'ower', '1BHK', '0', 0, '', 'F08-09', '', '', 25),
('Nanaso Shankar Thorat', '', 'vidya corner', 'nanaso.thorat@gmail.com', '99604 4314', 'Fhat no 2 Parth Prayed  neyar Rui hospital MIDC Baramati  Dist. Pune Pin. 413133', '', 0, 'ower', '1BHK', '143.11', 0, '', 'G15', '', '', 26),
('Pritam Vasntrav Yadav', '', 'vidya corner', 'pritamyadav8196@gmail.com', '9324267495', 'विद्या कॉर्नर सुपर मार्केट, गाळा क्रमांक ३५, पेन्सिल चौक ,एमआयडीसी. बारामती. पिन ४१३१३३', '', 0, 'Renter', '1BHK', '0', 0, '', 'G35', '', '', 27),
('Kamlesh vijaykumar agawane', '', 'vidya corner', 'kamalesh.agawane8383@gmail.com', '9923298383', 'Baramati', '', 0, 'ower', '1BHK', '0', 0, '', 'G20', '', '', 28),
('Vaibhav Bharat Annadate', '', 'vidya corner', 'vaibhav100000@gmail.com', '9890905963', 'TRISHALA BHARAT,VIDYA HOUSING SOCIETY', '', 0, 'ower', '1BHK', '115.62', 0, '', 'B16', '', '', 29),
('Popat Darshraj Devkate', '', 'vidya corner', 'satyamelek2@gmail.com', '7020211212', 'Baramati', '', 0, 'ower', '1BHK', '113.30', 0, '', 'G41', '', '', 30),
('SHRIHARI GANPAT GHOLVE', '', 'vidya corner', 'vsgholve2k@gmail.com', '9890252312', 'Vinayak Bangala, Shriram Nagar, Bhigwan Road, BARAMATI, PUNE.', '', 0, 'ower', '1BHK', '139.40', 0, '', 'G51', '', '', 31),
('Vijay Nanabhau Kaple', '', 'vidya corner', 'vedantk2007@gmail.com', '7738154577', 'At post Gawali Nagar, Taluka Phaltan, Dist Satara', '', 0, 'ower', '1BHK', '0', 0, '', 'S10-11', '', '', 32),
('Mahendra hanumant salunke', '', 'vidya corner', 'msalunke79@gmail.com', '9890904007', 'Plot No A 29 MIDC Baramati', '', 0, 'ower', '1BHK', '0', 0, '', 'G22-23', '', '', 33),
('Zagade Ashok Gangaram', '', 'vidya corner', 'rakeshzagade99@gmail.com', '9011163399', 'M.I.D.C.Chowk Baramati', '', 0, 'ower', '1BHK', '165.06', 0, '', 'B09', '', '', 34),
('Balasaheb shripati kothavale', '', 'vidya corner', 'Kothavalebalasaheb5@gmail.com', '9224335555', 'Grinpark fese 2 flat no c.1 ground flower', '', 0, 'ower', '1BHK', '0', 0, '', 'G35', '', '', 35),
('Vikas Jaysingrao Thorat', '', 'vidya corner', 'thoratvikas285@gmail.com', '7059311311', 'Dinesh Bildcon 7Green Apartment A Wing Flat No. 406 Bhagwan Baba Nagar Rui. Baramati', '', 0, 'ower', '1BHK', '103.19', 0, '', 'G37', '', '', 36),
('Popatlal Oswal', '', 'vidya corner', 'popatlal.oswal@yahoo.com', '9422020000', 'Chandan Farm,Bhigwan Road.Baramati', '', 0, 'ower', '1BHK', '415.44', 0, '', 'G11-12-13', '', '', 37),
('Ganesh Sambhaji Salunkhe', '', 'vidya corner', 'Karansalunke36@gmail.com', '9049333636', 'Baramati', '', 0, 'Owner', '1BHK', '201.05', 0, '', 'B01', '', '', 39),
('Gajendra Sahebrao Salunkhe', '', 'vidya corner', 'Karansalunke36@gmail.com', '9049333636', 'Baramati', '', 0, 'Owner', 'Shop', '194.65', 0, '', 'B02', '', '', 40),
('1.Sarjerav Bapurao Waikar 2.Netajee Mohan Salunkhe', '', 'Vidya Corner', 'Karansalunke36@gmail.com', '9763988128', 'Baramati', '', 0, 'Owner', 'Shop', '194.65', 0, '', 'B03', '', '', 41),
('Mahabaleshwarwala Firoj H', '', 'Vidya Corner', 'hmtbmt@rediffmail.com', '9422020113', 'Bar', '', 0, 'Owner', 'Shop', '195.94', 0, '', 'B04', '', '', 42),
('Bhapkar Kamal Ghanshayam', '', 'Vidya Corner', 'bhapkarprashant18@gmail.com', '9773779726', 'Baramati', '', 0, 'Owner', 'Shop', '254.58', 0, '', 'B06', '', '', 43),
('Bhapkar Kamal Ghanshayam', '', 'Vidya Corner', 'bhapkarprashant18@gmail.com', '9773779726', 'Baramati', '', 0, 'Owner', 'Shop', '109.81', 0, '', 'B07', '', '', 44),
('Zagade Ashok Gangaram', '', 'Vidya Corner', 'rakeshzade99@gmail.com', '9011163399', 'Baramati', '', 0, 'Owner', 'Shop', '165.06', 0, '', 'B09', '', '', 45),
('Mokashi Bharat Madhukar', '', 'Vidya Corner', 'bharat.mokashi@yahoo.co.in', '9921412001', 'Katpal Tal. Baramati Dist. Pune', '', 0, 'Owner', 'Shop', '121.50', 0, '', 'B13', '', '', 46),
('Annadate Vaibhav Bhart', '', 'Vidya Corner', 'vaibhav100000@gmail.com', '9890905963', 'Baramati', '', 0, 'Owner', 'Shop', '170.49', 0, '', 'G15', '', '', 47),
('Annadate Vaibhav Bhart', '', 'Vidya Corner', 'vaibhav100000@gmail.com', '9890905963', 'Baramati', '', 0, 'Owner', 'Shop', '115.62', 0, '', 'B16', '', '', 48),
('Annadate Vaibhav Bhart', '', 'Vidya Corner', 'vaibhav100000@gmail.com', '9890905963', 'Baramati', '', 0, 'Owner', 'Shop', '148.50', 0, '', 'B35', '', '', 49),
('Wabale Anil Shivaji', '', 'Vidya Corner', 'trimurtimobile007@gmail.com', '9860305073', 'Baramati', '', 0, 'Owner', 'Shop', '165.06', 0, '', 'B19', '', '', 50),
('Mhetre Shivalal Gulabrao', '', 'Vidya Corner', 'vilasshinde80226@gmail.com', '9764502626', 'Baramati', '', 0, 'Owner', 'Shop', '166.14', 0, '', 'B20', '', '', 51),
('Mokashi Sachin Nanasaheb', '', 'Vidya Corner', 'sachinmokashivm@gmail.com', '9011020767', 'Katpal Tal. Baramati Dist. Pune', '', 0, 'Owner', 'Shop', '129.44', 0, '', 'B25', '', '', 52),
('Mokashi Sachin Nanasaheb', '', 'Vidya Corner', 'sachinmokashivm@gmail.com', '9011020767', 'Katpal Tal. Baramati Dist. Pune', '', 0, 'Owner', 'Shop', '131.00', 0, '', 'B26', '', '', 53),
('Dalavi Santosh Tukaram', '', 'Vidya Corner', 'santoshdalvi351@gmail.com', '8149335166', 'Baramati', '', 0, 'Owner', 'Shop', '160.93', 0, '', 'B30', '', '', 54);

-- --------------------------------------------------------

--
-- Table structure for table `add_meeting`
--

CREATE TABLE `add_meeting` (
  `meeting_title` varchar(50) NOT NULL,
  `meeting_description` varchar(100) NOT NULL,
  `meeting_status` varchar(100) NOT NULL,
  `created_date` varchar(50) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `add_notice`
--

CREATE TABLE `add_notice` (
  `notice_title` varchar(50) NOT NULL,
  `notice_description` varchar(100) NOT NULL,
  `notice_status` varchar(100) NOT NULL,
  `created_date` varchar(50) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `apartment_details`
--

CREATE TABLE `apartment_details` (
  `apart_name` varchar(50) NOT NULL,
  `apart_address` varchar(50) NOT NULL,
  `floor` varchar(50) NOT NULL,
  `wing` varchar(50) NOT NULL,
  `total_flat` int(50) NOT NULL,
  `manager_name` varchar(50) NOT NULL,
  `id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `apartment_details`
--

INSERT INTO `apartment_details` (`apart_name`, `apart_address`, `floor`, `wing`, `total_flat`, `manager_name`, `id`) VALUES
('Vidya Corner', 'Baramati ', '5', 'A ', 150, 'suhas khade ', 23);

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `bill_type` varchar(50) NOT NULL,
  `bill_date` date NOT NULL,
  `total_amount` int(50) NOT NULL,
  `bill_details` varchar(500) NOT NULL,
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `cur_read` int(50) NOT NULL,
  `pre_read` int(50) NOT NULL,
  `price` int(50) NOT NULL,
  `total_amount_letter` varchar(50) NOT NULL,
  `total_unit` varchar(50) NOT NULL,
  `flat_n` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bill_type`, `bill_date`, `total_amount`, `bill_details`, `id`, `name`, `cur_read`, `pre_read`, `price`, `total_amount_letter`, `total_unit`, `flat_n`) VALUES
('', '2022-12-20', 1212, 'paid', 10, '', 1211, 1211, 221, 'aaaaaaaa', '3', ''),
('', '2023-01-04', 0, '1', 44, 'rajendra', 121, 11, 11, '', '11', '6');

-- --------------------------------------------------------

--
-- Table structure for table `committee`
--

CREATE TABLE `committee` (
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact_no` varchar(12) NOT NULL,
  `alt_contact_no` varchar(12) NOT NULL,
  `mail_id` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `designation` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `complains`
--

CREATE TABLE `complains` (
  `complains_title` varchar(50) NOT NULL,
  `complains_Description` varchar(100) NOT NULL,
  `created_date` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `complains_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emp`
--

CREATE TABLE `emp` (
  `emp_name` varchar(50) NOT NULL,
  `emp_mail` varchar(50) NOT NULL,
  `emp_contact` int(12) NOT NULL,
  `emp_pre_address` varchar(100) NOT NULL,
  `emp_per_address` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `joining_date` date NOT NULL,
  `ending_date` date NOT NULL,
  `emp_pass` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `emp_status` varchar(50) DEFAULT NULL,
  `studentPhoto` varchar(40) DEFAULT NULL,
  `file` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `final_bill`
--

CREATE TABLE `final_bill` (
  `flat_number` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `water_unit` int(50) NOT NULL,
  `additional_water_unit` int(50) NOT NULL,
  `pending_bill` int(50) NOT NULL,
  `total_bill` varchar(100) NOT NULL,
  `bill_date` date DEFAULT NULL,
  `total_unit` int(50) NOT NULL,
  `m_amount` int(100) NOT NULL,
  `f_bill` varchar(100) NOT NULL,
  `id` int(11) NOT NULL,
  `water_bill` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `final_bill`
--

INSERT INTO `final_bill` (`flat_number`, `first_name`, `last_name`, `email`, `water_unit`, `additional_water_unit`, `pending_bill`, `total_bill`, `bill_date`, `total_unit`, `m_amount`, `f_bill`, `id`, `water_bill`) VALUES
('07', 'Akash shivasharan shinde', '', 'akashsshinde0707@gmail.com', 6, 3, 0, '370', '2023-03-04', 0, 1041, '1411', 3, ''),
('T23', 'B.M.Bhosale', '', 'bmbhosale99@gmail.com', 6, 6, 0, '790', '2023-04-03', 12, 534, '1323.7', 4, '790'),
('G31', 'Suhas & Dilip Dashrath Khade', '', 'shreyasfoto@gmail.com', 6, 8, 0, '941', '2023-03-16', 14, 204, '1145.23', 6, '930');

-- --------------------------------------------------------

--
-- Table structure for table `final_bill2`
--

CREATE TABLE `final_bill2` (
  `flat_number` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cash_amount` varchar(100) NOT NULL,
  `online_amount` varchar(100) NOT NULL,
  `water_unit` int(50) NOT NULL,
  `additional_water_unit` int(50) NOT NULL,
  `pending_bill` int(50) NOT NULL,
  `total_bill` int(50) NOT NULL,
  `bill_date` date DEFAULT NULL,
  `m_amount` int(100) NOT NULL,
  `f_bill` int(100) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `final_bill2`
--

INSERT INTO `final_bill2` (`flat_number`, `first_name`, `last_name`, `email`, `cash_amount`, `online_amount`, `water_unit`, `additional_water_unit`, `pending_bill`, `total_bill`, `bill_date`, `m_amount`, `f_bill`, `id`) VALUES
('07', 'Akash shivasharan shinde', '', 'akashsshinde0707@gmail.com', '', '', 6, 3, 0, 370, '2023-03-04', 1041, 1411, 3),
('T23', 'B.M.Bhosale', '', 'bmbhosale99@gmail.com', '', '', 6, 2, 0, 510, '2023-03-16', 534, 1044, 4),
('T23', 'B.M.Bhosale', '', 'bmbhosale99@gmail.com', '', '', 2, 7, 0, 860, '2023-03-16', 534, 1394, 5),
('G31', 'Suhas & Dilip Dashrath Khade', '', 'shreyasfoto@gmail.com', '', '', 6, 3, 0, 580, '2023-03-16', 204, 784, 6),
('G31', 'Suhas & Dilip Dashrath Khade', '', 'shreyasfoto@gmail.com', '', '', 3, 0, 0, 370, '2023-03-16', 204, 574, 7),
('G31', 'Suhas & Dilip Dashrath Khade', '', 'shreyasfoto@gmail.com', '', '', 3, 0, 0, 370, '2023-03-16', 204, 574, 8),
('G31', 'Suhas & Dilip Dashrath Khade', '', 'shreyasfoto@gmail.com', '', '', 6, 4, 0, 650, '2023-03-16', 204, 854, 9),
('G31', 'Suhas & Dilip Dashrath Khade', '', 'shreyasfoto@gmail.com', '', '', 6, 4, 0, 650, '2023-03-16', 204, 854, 10),
('G31', 'Suhas & Dilip Dashrath Khade', '', 'shreyasfoto@gmail.com', '', '', 6, 4, 0, 650, '2023-03-16', 204, 854, 11),
('G31', 'Suhas & Dilip Dashrath Khade', '', 'shreyasfoto@gmail.com', '', '', 6, 4, 0, 650, '2023-03-16', 204, 854, 12),
('G31', 'Suhas & Dilip Dashrath Khade', '', 'shreyasfoto@gmail.com', '', '', 6, 3, 0, 580, '2023-03-16', 204, 784, 13),
('G31', 'Suhas & Dilip Dashrath Khade', '', 'shreyasfoto@gmail.com', '', '', 6, 8, 11, 941, '2023-03-16', 204, 1145, 14),
('T23', 'B.M.Bhosale', '', 'bmbhosale99@gmail.com', '', '', 6, 6, 0, 790, '2023-04-03', 534, 1324, 15);

-- --------------------------------------------------------

--
-- Table structure for table `flat_details`
--

CREATE TABLE `flat_details` (
  `flat_no` int(50) NOT NULL,
  `flat_wing_no` varchar(50) NOT NULL,
  `flat_owner_name` varchar(50) NOT NULL,
  `mob_no` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `flat_address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE `maintenance` (
  `m_title` varchar(100) NOT NULL,
  `m_dale` date NOT NULL,
  `m_amount` int(50) NOT NULL,
  `m_remark` varchar(100) NOT NULL,
  `id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `maintenance`
--

INSERT INTO `maintenance` (`m_title`, `m_dale`, `m_amount`, `m_remark`, `id`) VALUES
('aaa', '2023-04-04', 111, 'aa', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment_mode`
--

CREATE TABLE `payment_mode` (
  `ifsc_code` varchar(50) NOT NULL,
  `account_no` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `br_name` varchar(100) NOT NULL,
  `br_address` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `id` int(11) NOT NULL,
  `bank_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_mode`
--

INSERT INTO `payment_mode` (`ifsc_code`, `account_no`, `name`, `br_name`, `br_address`, `file`, `id`, `bank_name`) VALUES
('HDFC0CPDCCB', '009000100000627', 'VIDYA CORNER SUPER MARKET CO OP HOU SOC M.I.D.C.BARAMATI', 'Baramati Main', 'Baramati', 'd41d8cd98f00b204e9800998ecf8427e1673953938jpeg', 2, 'PUNE DISTRICT CENTRAL CO-OP.BANK LTD. PUNE');

-- --------------------------------------------------------

--
-- Table structure for table `pre_bill`
--

CREATE TABLE `pre_bill` (
  `flat_number` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `water_bill` varchar(100) NOT NULL,
  `water_bill_date` varchar(100) NOT NULL,
  `maintenance_bill` varchar(100) NOT NULL,
  `maintenance_bill_date` varchar(100) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pre_bill`
--

INSERT INTO `pre_bill` (`flat_number`, `full_name`, `water_bill`, `water_bill_date`, `maintenance_bill`, `maintenance_bill_date`, `id`) VALUES
('231', 'akash shinde', '232', '2023-01-17', '2357', '2023-01-17', 1);

-- --------------------------------------------------------

--
-- Table structure for table `unit_master`
--

CREATE TABLE `unit_master` (
  `unit` int(100) NOT NULL,
  `fix_rate` int(100) NOT NULL,
  `extra_rate` int(100) NOT NULL,
  `total` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `unit_master`
--

INSERT INTO `unit_master` (`unit`, `fix_rate`, `extra_rate`, `total`) VALUES
(1, 370, 0, 370),
(2, 370, 0, 370),
(3, 370, 0, 370),
(4, 370, 0, 370),
(5, 370, 0, 370),
(6, 370, 0, 370),
(7, 370, 70, 440),
(8, 370, 140, 510),
(9, 370, 210, 580),
(10, 370, 280, 650),
(11, 370, 350, 720),
(12, 370, 420, 790),
(13, 370, 490, 860),
(14, 370, 560, 930),
(15, 370, 630, 1000),
(16, 370, 700, 1070),
(17, 370, 770, 1140),
(18, 370, 840, 1210),
(19, 370, 910, 1280),
(20, 370, 980, 1350),
(21, 370, 1050, 1420),
(22, 370, 1120, 1490),
(23, 370, 1190, 1560),
(24, 370, 1260, 1630),
(25, 370, 1330, 1700),
(26, 370, 1400, 1770),
(27, 370, 1470, 1840),
(28, 370, 1540, 1910),
(29, 370, 1610, 1980),
(30, 370, 1680, 2050),
(31, 370, 1830, 2200);

--
-- Triggers `unit_master`
--
DELIMITER $$
CREATE TRIGGER `unit_master_record` BEFORE INSERT ON `unit_master` FOR EACH ROW BEGIN

   
   SET NEW.total = NEW.fix_rate+NEW.extra_rate;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `up_img`
--

CREATE TABLE `up_img` (
  `email` varchar(50) NOT NULL,
  `file` varchar(100) DEFAULT NULL,
  `bill_date` varchar(50) NOT NULL,
  `flat_number` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `up_img`
--

INSERT INTO `up_img` (`email`, `file`, `bill_date`, `flat_number`) VALUES
('akboyshinde007@gmail.com', 'upload/phone pay.jpeg', '2023-01-16', 5),
('akboyshinde007@gmail.com', 'upload/YUPWQwnT_400x400.jpg', '2023-01-16', 5),
('rohan01@gmail.com', 'upload/Screenshot (7).png', '2023-01-18', 1),
('akboyshinde007@gmail.com', 'upload/phone pay.jpeg', '2023-01-18', 5),
('akboyshinde007@gmail.com', 'upload/bgok.jpg', '2023-02-23', 5),
('shreyasfoto@gmail.com', 'upload/bg1.jpeg', '2023-03-16', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `username` varchar(300) DEFAULT NULL,
  `email` varchar(300) DEFAULT NULL,
  `password` varchar(300) DEFAULT NULL,
  `date` date NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `passwordConfirm` varchar(100) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`fname`, `lname`, `username`, `email`, `password`, `date`, `image`, `passwordConfirm`, `id`) VALUES
('suhas', 'khade', 'suhaskhade', 'shreyasfoto@gmail.com', '$2y$04$OuVztnfF3NX0cJ.XprMSke859mR7FALiCFRYvYM4/boVUb0BOVH2a', '2023-03-16', NULL, 'Suhas@123', 1),
('akash', 'shinde', 'akash-okispl', 'akashsshinde0707@gmail.com', '$2y$04$BGHees9M7c.Ut9UVPcSQAeGO7/jm0vEZyJLpr9rw4LRkdHcnDlWVu', '2022-12-21', NULL, 'Mango', 2),
('shankar', 'tormal', 'shankar1777', 'shankartormal1777@gmail.com', '$2y$04$u1i/oqFrzeObLEvFAP9fUez0UQx9OBlMLSnnomwNXBk3GbF5ZNGfq', '2022-12-22', NULL, '123456', 3),
('bhauso', 'bhosale', 'bm9696', 'bmbhosale96@gmail.com', '$2y$04$fjprMzv5nHxaxEF2tNQQNuse6t/QdVQrvaAyPILDpfc4uu4/JqZKy', '2023-03-21', NULL, 'bm@9696', 4),
('Rajendra', 'Thorat', 'Rajendra123', 'rajendra.thorat2000@gmail.com', '$2y$04$JRzuBQRRlTZCrmUXytaVqOI72dP5iXSvW4QILj.je45TvE5ObzB5y', '2023-03-29', NULL, '123456', 5);

-- --------------------------------------------------------

--
-- Table structure for table `users_admin`
--

CREATE TABLE `users_admin` (
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `username` varchar(300) DEFAULT NULL,
  `email` varchar(300) DEFAULT NULL,
  `password` varchar(300) DEFAULT NULL,
  `date` date NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `passwordConfirm` varchar(100) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_admin`
--

INSERT INTO `users_admin` (`fname`, `lname`, `username`, `email`, `password`, `date`, `image`, `passwordConfirm`, `id`) VALUES
('Akash', 'shinde', 'Akashshinde', 'akashsshinde0707@gmail.com', '$2y$04$RL5NPj6EmQAhynirbxSAjOBpv4BP9JBhD/umDmp4qY030OBXxoe9e', '2023-03-04', NULL, 'Akash@123', 1),
('suhas', 'khade', 'suhaskhade', 'shreyasfoto@gmail.com', '$2y$04$wPSA5qU3bAYyzJJoPUuhD./jZJX9TxJSKfiuL53iXxGWEJNuBSs4S', '2023-03-16', NULL, 'Suhas@123', 4),
('bhauso', 'bhosale', 'bm9696', 'bmbhosale96@gmail.com', '$2y$04$jcIFFWuB9x/CahJucqSClefXah5mj3A.6qcp.2tMdSifcFEuB5/tC', '2023-03-21', NULL, 'bm@9696', 5);

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `visitor`
--

CREATE TABLE `visitor` (
  `v_name` varchar(50) NOT NULL,
  `v_date` date NOT NULL,
  `v_address` varchar(50) NOT NULL,
  `mobile_no` varchar(12) NOT NULL,
  `relative_name` varchar(50) NOT NULL,
  `flat_no` int(100) NOT NULL,
  `wing_no` varchar(50) NOT NULL,
  `in_time` varchar(100) NOT NULL,
  `out_time` varchar(100) NOT NULL,
  `id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `visitor`
--

INSERT INTO `visitor` (`v_name`, `v_date`, `v_address`, `mobile_no`, `relative_name`, `flat_no`, `wing_no`, `in_time`, `out_time`, `id`) VALUES
('q', '2023-04-04', 'q', '1111111111', 'q', 2, 'a', '12:00 PM', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_event`
--
ALTER TABLE `add_event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_flat`
--
ALTER TABLE `add_flat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_meeting`
--
ALTER TABLE `add_meeting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_notice`
--
ALTER TABLE `add_notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apartment_details`
--
ALTER TABLE `apartment_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `committee`
--
ALTER TABLE `committee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complains`
--
ALTER TABLE `complains`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp`
--
ALTER TABLE `emp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `final_bill`
--
ALTER TABLE `final_bill`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `flat_number` (`flat_number`);

--
-- Indexes for table `final_bill2`
--
ALTER TABLE `final_bill2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `payment_mode`
--
ALTER TABLE `payment_mode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pre_bill`
--
ALTER TABLE `pre_bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit_master`
--
ALTER TABLE `unit_master`
  ADD PRIMARY KEY (`unit`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_admin`
--
ALTER TABLE `users_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `visitor`
--
ALTER TABLE `visitor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_flat`
--
ALTER TABLE `add_flat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `final_bill`
--
ALTER TABLE `final_bill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `final_bill2`
--
ALTER TABLE `final_bill2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `pre_bill`
--
ALTER TABLE `pre_bill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users_admin`
--
ALTER TABLE `users_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
