<?php

$to_email = "shankarmanali96@gmail.com";
$subject = "Your Recovered Password";
$body = "Please use this password to login ";
$headers = "From: shankartormal1777@gmail.com";

if(mail($to_email, $subject, $body, $headers)) {
    echo "Your Password has been sent to $to_email...";
} else {
    echo "Failed to Recover your password, try again";
}

?>
