<?php require_once("db.php");
?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Building Maintenance</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="bm/images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="bm/css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="bm/style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="bm/css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="bm/css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="bm/css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="bm/css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="bm/css/custom.css" />
      <!-- calendar file css -->
      <link rel="stylesheet" href="bm/js/semantic.min.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href="bm/index.php"><img class="logo_icon img-responsive" src="bm/images/logo/BM PNG.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" style="background-color:white;" src="bm/images/logo/BM PNG.png" alt="#" /></div>
                        <div class="user_info">
                            <p><span class="online_animation"></span>&nbsp;Online</p>

                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>Admin Dashboard</h4>

               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="bm/index.php"><img class="img-responsive" src="bm/images/logo/BM22.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info" style="color:white;" id="draw">
                               <ul>

                              </ul>

                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Admin Registration.....!</h2>
                           </div>
                        </div>
                     </div>




<?php
 if(isset($_POST['signup'])){
  extract($_POST);
  if(strlen($fname)<3){ // Minimum
      $error[] = 'Please enter First Name using 3 charaters atleast.';
        }
if(strlen($fname)>20){  // Max
      $error[] = 'First Name: Max length 20 Characters Not allowed';
        }
if(!preg_match("/^[A-Za-z _]*[A-Za-z ]+[A-Za-z _]*$/", $fname)){
            $error[] = 'Invalid Entry First Name. Please Enter letters without any Digit or special symbols like ( 1,2,3#,$,%,&,*,!,~,`,^,-,)';
        }
if(strlen($lname)<3){ // Minimum
      $error[] = 'Please enter Last Name using 3 charaters atleast.';
        }
if(strlen($lname)>20){  // Max
      $error[] = 'Last Name: Max length 20 Characters Not allowed';
        }
if(!preg_match("/^[A-Za-z _]*[A-Za-z ]+[A-Za-z _]*$/", $lname)){
            $error[] = 'Invalid Entry Last Name. Please Enter letters without any Digit or special symbols like ( 1,2,3#,$,%,&,*,!,~,`,^,-,)';
              }
      if(strlen($username)<3){ // Change Minimum Lenghth
            $error[] = 'Please enter Username using 3 charaters atleast.';
        }
  if(strlen($username)>50){ // Change Max Length
            $error[] = 'Username : Max length 50 Characters Not allowed';
        }
  if(!preg_match("/^^[^0-9][a-z0-9]+([_-]?[a-z0-9])*$/", $username)){
            $error[] = 'Invalid Entry for Username. Enter lowercase letters without any space and No number at the start- Eg - myusername, okuniqueuser or myusername123';
        }
if(strlen($email)>50){  // Max
            $error[] = 'Email: Max length 50 Characters Not allowed';
        }
   if($passwordConfirm ==''){
            $error[] = 'Please confirm the password.';
        }
        if($password != $passwordConfirm){
            $error[] = 'Passwords do not match.';
        }
          if(strlen($password)<5){ // min
            $error[] = 'The password is 6 characters long.';
        }

         if(strlen($password)>20){ // Max
            $error[] = 'Password: Max length 20 Characters Not allowed';
        }
          $sql="select * from users where (username='$username' or email='$email');";
      $res=mysqli_query($con,$sql);
   if (mysqli_num_rows($res) > 0) {
$row = mysqli_fetch_assoc($res);

     if($username==$row['username'])
     {
           $error[] ='Username alredy Exists.';
          }
       if($email==$row['email'])
       {
            $error[] ='Email alredy Exists.';
          }
      }
         if(!isset($error)){
              $date=date('Y-m-d');
               $options = array("cost"=>4);
    $password = password_hash($password,PASSWORD_BCRYPT,$options);


            $result = mysqli_query($con,"INSERT into users(fname,lname,username,email,password,date,passwordConfirm) values('$fname','$lname','$username','$email','$password','$date','$passwordConfirm')");

           if($result)
    {
     $done=2;
    }
    else{
      $error[] ='Failed : Something went wrong';
    }
 }
 } ?>

		 <div class="col-sm-4">

 <?php
  if(isset($error)){
foreach($error as $error){
  echo '<p class="errmsg">&#x26A0;'.$error.' </p>';
}
}
?>
		</div>
		<div class="col-sm-4">
      <?php if(isset($done))
      { ?>
    <div class="successmsg"><span style="font-size:100px;">&#9989;</span> <br> You have registered successfully . <br> <a href="bm/index.php" style="color:red;">Go Home Page... </a> </div>
      <?php } else { ?>
       <div class="signup_form" style="color:black;">
		<form action="" method="POST">
  <div class="form-group">

        <label class="label_txt">First Name</label>
    <input type="text" class="form-control" name="fname" value="<?php if(isset($error)){ echo $_POST['fname'];}?>" required="">
  </div>
  <div class="form-group">
    <label class="label_txt">Last Name </label>
    <input type="text" class="form-control" name="lname" value="<?php if(isset($error)){ echo $_POST['lname'];}?>" required="">
  </div>

<div class="form-group">
    <label class="label_txt">Username </label>
    <input type="text" class="form-control" name="username" value="<?php if(isset($error)){ echo $_POST['username'];}?>" required="">
  </div>

<div class="form-group">
    <label class="label_txt">Email </label>
    <input type="email" class="form-control" name="email" value="<?php if(isset($error)){ echo $_POST['email'];}?>" required="">
  </div>
  <div class="form-group">
    <label class="label_txt">Password </label>
    <input type="password" name="password" class="form-control" required="">
  </div>
   <div class="form-group">
    <label class="label_txt">Confirm Password </label>
    <input type="password" name="passwordConfirm" class="form-control" required="">
  </div>
  <button type="submit" name="signup" class="btn btn-primary btn-group-lg form_btn">Create</button>
</form>
<?php } ?>
</div>
		</div>
		<div class="col-sm-4">
		</div>

	</div>
</div>
</body>
 <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
      <script src="bm/js/jquery.min.js"></script>
      <script src="bm/js/popper.min.js"></script>
      <script src="bm/js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="bm/js/animate.js"></script>
      <!-- select country -->
      <script src="bm/js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="bm/js/owl.carousel.js"></script>
      <!-- chart js -->
      <script src="bm/js/Chart.min.js"></script>
      <script src="bm/js/Chart.bundle.min.js"></script>
      <script src="bm/js/utils.js"></script>
      <script src="bm/js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="bm/js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="bm/js/custom.js"></script>
      <!-- calendar file css -->
      <script src="bm/js/semantic.min.js"></script>
</html>
