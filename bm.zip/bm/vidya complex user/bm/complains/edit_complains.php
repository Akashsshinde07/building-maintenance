
<?php
//getting id from url
include_once("../../db.php");
if(!isset($_SESSION["login_sess"]))
{
    header("location:login.php");
}
  $email=$_SESSION["login_email"];
  $findresult = mysqli_query($con, "SELECT * FROM users_admin WHERE email= '$email'");
  if($res = mysqli_fetch_array($findresult))
{
$username = $res['username'];
$fname = $res['fname'];
$lname = $res['lname'];
$email = $res['email'];
$image= $res['image'];
}

$id = $_GET['edit'];

//selecting data associated with this particular id
$result = mysqli_query($con, "SELECT * FROM complains WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
    $complains_title = $res['complains_title'];
    $complains_Description = $res['complains_Description'];
    $created_date = $res['created_date'];
}
?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Building Maintenance</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="../images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="../css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="../style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="../css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="../css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="../css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="../css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="../css/custom.css" />
      <!-- calendar file css -->
      <link rel="stylesheet" href="../js/semantic.min.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href="index.php"><img class="logo_icon img-responsive" src="images/logo/BM PNG.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" style="background-color:white;" src="../images/logo/BM PNG.png" alt="#" /></div>
                        <div class="user_info">
                        <?php echo $username; ?>
                            <p><span class="online_animation"></span>&nbsp;Online</p>

                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>User Dashboard</h4>
                  <ul class="list-unstyled components">
                     <li class="active"><a href="profile.php"><i class="fa fa-lock orange_color"></i> <span>Change Password</span></a></li>
                     <li class="active"><a href="../index.php"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a></li>

                     <li>
                        <a href="#apps" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-comments orange_color"></i> <span>Complaints</span></a>
                        <ul class="collapse list-unstyled" id="apps">
                           <li><a href="../complains/complains.php">> <span>Add Complaints Details</span></a></li>
                           <li><a href="../complains/display_complains.php">> <span>View Complaints Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active"><a href="../collection/demo.php"><i class="fa fa-rupee yellow_color"></i> <span>View Bill</span></a></li>

                     <li class="active"><a href="../payment_mode.php"><i class="fa fa-cc-visa orange_color"></i> <span> Payment Modes</span></a></li>

                     <li class="active"><a href="../upload_pay.php"><i class="fa fa-upload yellow_color"></i> <span>Upload Payment Sleep</span></a></li>

                     <li class="active"><a href="../payment_upload.php"><i class="fa fa-eye orange_color"></i> <span>View Payment Sleep</span></a></li>

                     <li class="active"><a href="../../logout.php"><i class="fa fa-sign-out yellow_color"></i> <span>Log Out</span></a></li>

                  </ul>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="index.php"><img class="img-responsive" src="../images/logo/BM22.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info" style="color:white;" id="draw">
                               <ul>

                              </ul>

                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Edit Complains  Details.....!</h2>
                           </div>
                        </div>
                     </div>


                     <div class="container">


<form name="apartment_details" method="post" action="update_complains.php">
<fieldset>

<!-- Text input-->
<div>
<div class="form-group">

  <input  name="id" value="<?php echo $id; ?>" placeholder=" " class="hidden"  type="text" style="margin-left:8px;" required>

  </div>
</div>

<!-- Text input-->
<div style="color:black;">
<div class="form-group">
  <label class="col-md-4 control-label"><span style="color:red;">*</span>&nbsp; complains Title</label>
  <div class="col-md-4 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon" style="margin-top:8px;"><i class='fa fa-book' style='font-size:20px'></i></span>
  <input  name="complains_title" value="<?php echo $complains_title; ?>" placeholder=" " class="form-control"  type="text" style="margin-left:8px;" required>
    </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" ><span style="color:red;">*</span>&nbsp;complains Description</label>
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon" style="margin-top:8px;"><i class='fa fa-commenting' style='font-size:20px'></i></span>
  <input name="complains_Description" value="<?php echo $complains_Description; ?>" placeholder=" " class="form-control"  type="text" style="margin-left:8px;" required>
    </div>
  </div>
</div>

<!-- Text input-->
   <div class="form-group">
  <label class="col-md-4 control-label">Created Date</label>
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon" style="margin-top:8px;"><i class='fa fa-calendar' style='font-size:20px'></i></span>
  <input name="created_date" value="<?php echo $created_date; ?>" placeholder=" " class="form-control" type="date" style="margin-left:8px;" required>
    </div>
  </div>
</div>

  </div>
</div>


<!-- Select Basic -->

<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4">
    <button type="submit" value="Update" class="btn btn-warning" name="update">Update <span class="glyphicon glyphicon-send"></span></button>

  </div>
</div>

</fieldset>
</form>
</div>
    </div><!-- /.container -->

      <!-- jQuery -->
      <script src="../js/jquery.min.js"></script>
      <script src="../js/popper.min.js"></script>
      <script src="../js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="../js/animate.js"></script>
      <!-- select country -->
      <script src="../js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="../js/owl.carousel.js"></script>
      <!-- chart js -->
      <script src="../js/Chart.min.js"></script>
      <script src="../js/Chart.bundle.min.js"></script>
      <script src="../js/utils.js"></script>
      <script src="../js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="../js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="../js/custom.js"></script>
      <!-- calendar file css -->
      <script src="../js/semantic.min.js"></script>

               </div></div></div></div>
   </body>
</html>