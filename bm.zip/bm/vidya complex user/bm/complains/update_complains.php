<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];

$complains_title = $_POST['complains_title'];
$complains_Description = $_POST['complains_Description'];
$created_date = $_POST['created_date'];


        //updating the table
        $result = mysqli_query($con, "UPDATE complains SET complains_title='$complains_title', complains_Description='$complains_Description',
        created_date='$created_date' WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_complains.php");
    }

?>