<?php require_once("../db.php");
if(!isset($_SESSION["login_sess"]))
{
    header("location:login.php");
}
  $email=$_SESSION["login_email"];
  $findresult = mysqli_query($con, "SELECT * FROM users_admin WHERE email= '$email'");
if($res = mysqli_fetch_array($findresult))
{
$username = $res['username'];
$fname = $res['fname'];
$lname = $res['lname'];
$email = $res['email'];
$image= $res['image'];
}
 ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Building Maintenance</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="css/custom.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
    <style>

.blue {
    background: red;

}

.news {
     position:relative;
  display: flex;
    box-shadow: inset 0 -15px 30px rgba(0,0,0,0.4), 0 5px 10px rgba(0,0,0,0.5);
       width: 95%;
    margin: 20px auto;
    overflow: hidden;
    border-radius: 4px;
    padding: 1px;
    -webkit-user-select: none;
}

.news span {
    float: left;
    color: red;

    padding: 9px;
    position: relative;
    top: 1%;
    box-shadow: inset 0 -15px 30px rgba(0,0,0,0.4);
    font: 16px 'Raleway', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -webkit-user-select: none;
    cursor: pointer;
}

.text1{

 box-shadow:none !important;
    width: 750px;
    background: white;
}

.imagebox {
  width: 50%;
  float: right;
}

.textbox {
  width: 50%;
  float: left;
  text-align: center;
  padding-top: 100px;

}
</style>
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href="index.php"><img class="logo_icon img-responsive" src="images/logo/BM PNG.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" style="background-color:white;" src="images/logo/BM PNG.png" alt="#" /></div>
                        <div class="user_info">
                        <?php echo $username; ?>
                            <p><span class="online_animation"></span>&nbsp;Online</p>

                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>User Dashboard</h4>
                  <ul class="list-unstyled components">
                     <li class="active"><a href="profile.php"><i class="fa fa-lock orange_color"></i> <span>Change Password</span></a></li>
                     <li class="active"><a href="index.php"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a></li>

                     <li>
                        <a href="#apps" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-comments orange_color"></i> <span>Complaints</span></a>
                        <ul class="collapse list-unstyled" id="apps">
                           <li><a href="complains/complains.php">> <span>Add Complaints Details</span></a></li>
                           <li><a href="complains/display_complains.php">> <span>View Complaints Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active"><a href="collection/demo.php"><i class="fa fa-rupee yellow_color"></i> <span>View Bill</span></a></li>

                     <li class="active"><a href="payment_mode.php"><i class="fa fa-cc-visa orange_color"></i> <span> Payment Modes</span></a></li>

                     <li class="active"><a href="upload_pay.php"><i class="fa fa-upload yellow_color"></i> <span>Upload Payment Sleep</span></a></li>

                     <li class="active"><a href="payment_upload.php"><i class="fa fa-eye orange_color"></i> <span>View Payment Sleep</span></a></li>

                     <li class="active"><a href="../logout.php"><i class="fa fa-sign-out yellow_color"></i> <span>Log Out</span></a></li>

                  </ul>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="index.php"><img class="img-responsive" src="images/logo/BM22.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info" style="color:white;" id="draw">
                               <ul>

                              </ul>

                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                     <div class="price_table_head green_bg" style="margin-top:2%;">
                        <h2>Payment Details</h2>
                    </div>

                    </div>
                     </div>

                    <?php $results = mysqli_query($con, "SELECT * FROM payment_mode"); ?>
                    <?php while ($row = mysqli_fetch_array($results)) { ?>
                    <div class="imagebox">
                    <img src="../../bm/payment_mode/images1/<?php echo $row['file'];?>" width="100%" height="400px" />

                    </div>


                    <div class="textbox" >

                      <p style="color: black;"><b>IFSC Code: </b><?php echo $row['ifsc_code']; ?></p>
                      <p style="color: black;"><b>Account Number: </b><?php echo $row['account_no']; ?></p>
                      <p style="color: black;"><b>Name: </b><?php echo $row['name']; ?></p>
                      <p style="color: black;"><b>Bank Name: </b><?php echo $row['bank_name']; ?></p>
                      <p style="color: black;"><b>Branch Name: </b><?php echo $row['br_name']; ?></p>
                      <p style="color: black;"><b>Branch Address: </b><?php echo $row['br_address']; ?></p>

                    </div>
                    <?php } ?>
                     </div>
                  </div>

               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="js/animate.js"></script>
      <!-- select country -->
      <script src="js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="js/owl.carousel.js"></script>
      <!-- chart js -->
      <script src="js/Chart.min.js"></script>
      <script src="js/Chart.bundle.min.js"></script>
      <script src="js/utils.js"></script>
      <script src="js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="js/custom.js"></script>
      <script src="js/chart_custom_style1.js"></script>
   </body>
</html>

