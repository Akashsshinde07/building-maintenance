<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $flat_number = $_POST['flat_number'];
    $pre_reading = $_POST['pre_reading'];


        //updating the table
        $result = mysqli_query($con, "UPDATE final_bill SET pre_reading='$pre_reading'
         WHERE flat_number=$flat_number");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_bill.php");
    }

?>