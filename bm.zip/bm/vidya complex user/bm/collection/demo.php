<?php
include('../../db.php');
if(!isset($_SESSION["login_sess"]))
{
    header("location:login.php");
}
  $email=$_SESSION["login_email"];
  $findresult = mysqli_query($con, "SELECT * FROM users_admin WHERE email= '$email'");
  if($res = mysqli_fetch_array($findresult))
{
$username = $res['username'];
$fname = $res['fname'];
$lname = $res['lname'];
$email = $res['email'];
$image= $res['image'];
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Building Maintenance</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="../css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="../style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="../css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="../css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="../css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="../css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="../css/custom.css" />
      <!-- calendar file css -->
      <link rel="stylesheet" href="../js/semantic.min.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <style>

/* Container Border */
.container {
padding: 5px;
width:80%;
}
form {border: 3px solid black;}
.as {border-top: 1px solid black;}
.asr {border-bottom: 1px solid black;}
</style>
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href="../index.php"><img class="logo_icon img-responsive" src="../images/logo/BM PNG.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" style="background-color:white;" src="../images/logo/BM PNG.png" alt="#" /></div>
                        <div class="user_info">
                        <?php echo $username; ?>
                            <p><span class="online_animation"></span>&nbsp;Online</p>

                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>User Dashboard</h4>
                  <ul class="list-unstyled components">
                     <li class="active"><a href="../profile.php"><i class="fa fa-lock orange_color"></i> <span>Change Password</span></a></li>
                     <li class="active"><a href="../index.php"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a></li>

                     <li>
                        <a href="#apps" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-comments orange_color"></i> <span>Complaints</span></a>
                        <ul class="collapse list-unstyled" id="apps">
                           <li><a href="../complains/complains.php">> <span>Add Complaints Details</span></a></li>
                           <li><a href="../complains/display_complains.php">> <span>View Complaints Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active"><a href="../collection/demo.php"><i class="fa fa-rupee yellow_color"></i> <span>View Bill</span></a></li>

                     <li class="active"><a href="../payment_mode.php"><i class="fa fa-cc-visa orange_color"></i> <span> Payment Modes</span></a></li>

                     <li class="active"><a href="../upload_pay.php"><i class="fa fa-upload yellow_color"></i> <span>Upload Payment Sleep</span></a></li>

                     <li class="active"><a href="../payment_upload.php"><i class="fa fa-eye orange_color"></i> <span>View Payment Sleep</span></a></li>

                     <li class="active"><a href="../../logout.php"><i class="fa fa-sign-out yellow_color"></i> <span>Log Out</span></a></li>

                  </ul>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="index.php"><img class="img-responsive" src="../images/logo/BM22.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info" style="color:white;" id="draw">
                               <ul>

                              </ul>

                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Bill.....!</h2>
                           </div>
                        </div>
                     </div>





</div>
    </div><!-- /.container -->
<?php $results = mysqli_query($con, "SELECT * FROM final_bill WHERE email='$email'");?>
<?php while ($row = mysqli_fetch_array($results)) { ?>
<!--div class="container"-->
<form class="container">
    <div style="text-align:center;"  class="asr">
        <h3>Vidya Corner Super Market<br> Co-op. Housing Society Ltd.</h3>
        <h5>Plot P-15,M.I.D.C. Baramati, Dist-pune 413133<br>
        Reg No. PNA/BAI/HSG/TC/8707/2008/Dt. 10/07/2008<br>
        सुहास खाडे Mob. 7588594988 बाळासाहेब कारंडे Mob. 9822879536</h5>
    </div>

    <h4>No. &nbsp&nbsp&nbsp<?php echo $row['id']; ?>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    Date:-&nbsp&nbsp<?php echo $row['bill_date']; ?></h4>
    <h5>नाव &nbsp&nbsp:-&nbsp&nbsp <?php echo $row['first_name']; ?>&nbsp&nbsp<?php echo $row['last_name']; ?></h5>
    <h5 style="margin-top:2%;">फ्लॅट क्रमांक &nbsp&nbsp:-&nbsp&nbsp <input  style="text-align:center;" value="<?php echo $row['flat_number']; ?>" readonly/></h5>

    <h5 style="margin-top:2%;">एकूण युनीट  &nbsp&nbsp:-&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['total_unit']; ?></h5>
    <h5 style="margin-top:2%;">मागील रक्कम  &nbsp&nbsp:-&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['pending_bill']; ?></h5>

    <?php $results = mysqli_query($con, "SELECT * FROM final_bill WHERE email='$email' "); ?>
    <?php while ($row = mysqli_fetch_array($results)) { ?>
    <h5>पाणी बिल  &nbsp&nbsp:-&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['water_bill']; ?></h5>

    <?php } ?>

    <?php $results = mysqli_query($con, "SELECT * FROM add_flat WHERE e_mail='$email' "); ?>
    <?php while ($row = mysqli_fetch_array($results)) { ?>
    <h5 style="margin-top:2%;">मेन्टेनन्स रक्कम  &nbsp&nbsp:-&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['m_amount']; ?></h5>
    <?php } ?>

    <?php $results = mysqli_query($con, "SELECT * FROM final_bill WHERE email='$email'"); ?>
    <?php while ($row = mysqli_fetch_array($results)) { ?>
     <h5 class="as" style="margin-top:2%;">टोटल रक्कम &nbsp&nbsp:-&nbsp&nbsp&nbsp <?php echo $row['f_bill']; ?></h5>
     <?php } ?>

     <h5 style="margin-top:2%;">अक्षरी रु.  &nbsp&nbsp:-&nbsp&nbsp&nbsp
     <?php

    $result = mysqli_query($con, "SELECT * FROM final_bill WHERE email='$email'");

    while($res = mysqli_fetch_array($result))
    {
        $number = $res['f_bill'];
    }

       $no = floor($number);
       $point = round($number - $no, 2) * 100;
       $hundred = null;
       $digits_1 = strlen($no);
       $i = 0;
       $str = array();
       $words = array('0' => '', '1' => 'one', '2' => 'two',
        '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
        '7' => 'seven', '8' => 'eight', '9' => 'nine',
        '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
        '13' => 'thirteen', '14' => 'fourteen',
        '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
        '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
        '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
        '60' => 'sixty', '70' => 'seventy',
        '80' => 'eighty', '90' => 'ninety');
       $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
       while ($i < $digits_1) {
         $divider = ($i == 2) ? 10 : 100;
         $number = floor($no % $divider);
         $no = floor($no / $divider);
         $i += ($divider == 10) ? 1 : 2;
         if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number] .
                " " . $digits[$counter] . $plural . " " . $hundred
                :
                $words[floor($number / 10) * 10]
                . " " . $words[$number % 10] . " "
                . $digits[$counter] . $plural . " " . $hundred;
         } else $str[] = null;
      }
      $str = array_reverse($str);
      $result = implode('', $str);
      $points = ($point) ?
        "." . $words[$point / 10] . " " .
              $words[$point = $point % 10] : '';
      echo $result . "Rupees  " . $points . " Paise";
     ?>
     </h5>
     <h5 style="margin-top:5%;">गाळा धारकाची सही</h5>
     <h5 style="text-align:right;">Vidya Corner Super Market<br> Co-op. Housing Society Ltd.</h5>
     <h5>वरील बाकी ८दिवसात न आल्यास पुरवठा खंडीत केला जाईल.</h5>

</form>
<?php } ?>
<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>

      <script src="../js/jquery.min.js"></script>
      <script src="../js/popper.min.js"></script>
      <script src="../js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="../js/animate.js"></script>
      <!-- select country -->
      <script src="../js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="../js/owl.carousel.js"></script>
      <!-- chart js -->
      <script src="../js/Chart.min.js"></script>
      <script src="../js/Chart.bundle.min.js"></script>
      <script src="../js/utils.js"></script>
      <script src="../js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="../js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="../js/custom.js"></script>
      <!-- calendar file css -->
      <script src="../js/semantic.min.js"></script>

               </div></div></div></div>
   </body>
</html>



