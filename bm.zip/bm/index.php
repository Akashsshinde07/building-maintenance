<!DOCTYPE html>
<?php require_once("db.php"); ?>
<html>
<head><br>
<title> Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<script>
function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
<style>
body{

background-image: url('bg07.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}

</style>

</head>
<body>
<div class="container">
	<div class=" ">
		<div class="col-sm-4">
		</div>
		<div class="col-sm-4">
			<div class="login_form" style="color:red;">
 	<form action="login_process.php" method="POST">
  <div class="form-group">
 <img src="bm/images/logo/BM PNG.png" alt="bm" class="logo img-fluid" width="40%" style="margin-top:10%;margin-left:25%;margin-bottom:10%;"> <br>
<?php
if(isset($_GET['loginerror'])) {
	$loginerror=$_GET['loginerror'];
}
 if(!empty($loginerror)){  echo '<p class="errmsg">Invalid login credentials, Please Try Again..</p>'; } ?>


    <input style="text-align:center;" placeholder="Enter Your Username or Email" type="text" name="login_var" value="<?php if(!empty($loginerror)){ echo  $loginerror; } ?>" class="form-control" required="">
  </div>
  <div class="form-group">
    <input placeholder="Enter Your Password" type="password" name="password" class="form-control" id="myInput" required="" style="text-align:center; margin-top:10%; margin-bottom:5%;">
    <input type="checkbox" onclick="myFunction()">Show Password &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="forget_pass.php" style="color:red;">Reset Password</a>
  </div>

  <button type="submit" name="sublogin" class="btn btn-primary btn-group-lg form_btn" style="margin-top:5%;margin-left:40%;">Login</button>
</form>

		</div>
		</div>
	</div>
</div>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</html>
