<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];

    $m_title = $_POST['m_title'];
    $m_amount = $_POST['m_amount'];
    $m_remark = $_POST['m_remark'];


        //updating the table
        $result = mysqli_query($con, "UPDATE maintenance SET m_title='$m_title', m_amount='$m_amount', m_remark='$m_remark' WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_maintenance.php");
    }

?>