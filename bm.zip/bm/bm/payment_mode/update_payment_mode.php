<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];
    $ifsc_code = $_POST['ifsc_code'];
    $account_no = $_POST['account_no'];
    $name = $_POST['name'];
    $bank_name = $_POST['bank_name'];
    $br_name = $_POST['br_name'];
    $br_address = $_POST['br_address'];

        //updating the table
        $result = mysqli_query($con, "UPDATE payment_mode SET ifsc_code='$ifsc_code', account_no='$account_no', name='$name', bank_name='$bank_name', br_name='$br_name', br_address='$br_address'
        WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_payment_mode.php");
    }

?>