<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];
    $v_name = $_POST['v_name'];
    $v_address = $_POST['v_address'];
    $mobile_no = $_POST['mobile_no'];
    $relative_name = $_POST['relative_name'];
    $flat_no = $_POST['flat_no'];
    $wing_no = $_POST['wing_no'];
    $out_time = $_POST['out_time'];


        //updating the table
        $result = mysqli_query($con, "UPDATE visitor SET v_name='$v_name', v_address='$v_address', mobile_no='$mobile_no', relative_name='$relative_name', flat_no='$flat_no', wing_no='$wing_no', out_time='$out_time' WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_visitor.php");
    }

?>