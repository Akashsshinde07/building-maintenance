<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];

$complains_status = $_POST['complains_status'];

        //updating the table
        $result = mysqli_query($con, "UPDATE complains SET complains_status='$complains_status' WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_complains.php");
    }

?>