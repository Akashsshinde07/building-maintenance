<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];

	$event_title = $_POST['event_title'];
    $event_description = $_POST['event_description'];
    $event_status = $_POST['event_status'];
    $created_date = $_POST['created_date'];


        //updating the table
        $result = mysqli_query($con, "UPDATE add_event SET event_title='$event_title', event_description='$event_description',
	 event_status='$event_status', created_date='$created_date' WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_event.php");
    }

?>