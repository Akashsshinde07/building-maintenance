<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];

	$notice_title = $_POST['notice_title'];
    $notice_description = $_POST['notice_description'];
    $notice_status = $_POST['notice_status'];
    $created_date = $_POST['created_date'];


        //updating the table
        $result = mysqli_query($con, "UPDATE add_notice SET notice_title='$notice_title', notice_description='$notice_description',
	 notice_status='$notice_status', created_date='$created_date' WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_notice.php");
    }

?>