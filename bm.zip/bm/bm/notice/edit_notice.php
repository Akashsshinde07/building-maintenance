
<?php
//getting id from url
include_once("../../db.php");
if(!isset($_SESSION["login_sess"]))
{
    header("location:login.php");
}
  $email=$_SESSION["login_email"];
  $findresult = mysqli_query($con, "SELECT * FROM users WHERE email= '$email'");
  if($res = mysqli_fetch_array($findresult))
{
$username = $res['username'];
$fname = $res['fname'];
$lname = $res['lname'];
$email = $res['email'];
$image= $res['image'];
}

$id = $_GET['edit'];

//selecting data associated with this particular id
$result = mysqli_query($con, "SELECT * FROM add_notice WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
    $notice_title = $res['notice_title'];
    $notice_description = $res['notice_description'];
    $notice_status = $res['notice_status'];
    $created_date = $res['created_date'];

}
?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Building Maintenance</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="../images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="../css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="../style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="../css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="../css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="../css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="../css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="../css/custom.css" />
      <!-- calendar file css -->
      <link rel="stylesheet" href="../js/semantic.min.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
   </head>
   <body class="inner_page widgets">
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href="index.php"><img class="logo_icon img-responsive" src="../images/logo/BM PNG.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" style="background-color:white;" src="../images/logo/BM PNG.png" alt="#" /></div>
                        <div class="user_info">
                        <?php echo $username; ?>
                            <p><span class="online_animation"></span>&nbsp;Online</p>

                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>Admin Dashboard</h4>
                  <ul class="list-unstyled components">
                     <li class="active"><a href="../profile.php"><i class="fa fa-lock yellow_color"></i> <span>Change Password</span></a></li>

                     <li>
                        <a href="#apps1" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-table orange_color"></i> <span>Registration</span></a>
                        <ul class="collapse list-unstyled" id="apps1">
                           <li><a href="../../registration.php"> <span>Add Admin</span></a></li>
                           <li><a href="../admin_details.php"> <span>Admins Details</span></a></li>
                           <li><a href="../../user_registration.php"> <span>Add User</span></a></li>
                           <li><a href="../users_details.php"> <span>Users Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active"><a href="../index.php"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a></li>

                     <li>
                        <a href="#apps" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-table orange_color"></i> <span>Apartment</span></a>
                        <ul class="collapse list-unstyled" id="apps">
                           <li><a href="../apartment/apart.php">> <span>Add Apartment Details</span></a></li>
                           <li><a href="../apartment/display_apart.php">> <span>View Apartment Details</span></a></li>
                        </ul>
                     </li>

                     <li>
                     <a href="#element" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-building-o yellow_color"></i> <span>flats</span></a>
                        <ul class="collapse list-unstyled" id="element">
                           <li><a href="../flats/flat.php">> <span>Add Flat Details</span></a></li>
                           <li><a href="../flats/display_flat.php">> <span>View Flat Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active">
                        <a href="#additional_page" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-wrench orange_color"></i> <span>Maintenance</span></a>
                        <ul class="collapse list-unstyled" id="additional_page">
                           <li><a href="../Maintenance/maintenance.php">> <span>Add Maintenance Details</span></a></li>
                           <li><a href="../Maintenance/display_maintenance.php">> <span>View Maintenance Details</span></a></li>
                        </li>
                        </ul>
                     </li>

                     <li class="active">
                        <a href="#dashboard" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user yellow_color"></i> <span>Visitors</span></a>
                        <ul class="collapse list-unstyled" id="dashboard">
                           <li><a href="../Visitor/visitor.php">> <span>Add Visitor Details</span></a></li>
                           <li><a href="../Visitor/display_visitor.php">> <span>View Visitor Details</span></a></li>
                        </ul>
                     </li>

                     <li>
                        <a href="#flatbill" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-rupee orange_color"></i> <span>Flat Wise Bill</span></a>
                        <ul class="collapse list-unstyled" id="flatbill">
                           <li><a href="../collection/demo2.php"> <span>Add Bill Details</span></a></li>
                           <li><a href="../collection/display_bill.php"> <span>View Bill Details</span></a></li>
                           <li><a href="../collection/display_bill2.php"> <span>Add Cash Mode</span></a></li>
                        </ul>
                     </li>

                     <li>
                        <a href="#flatbill2" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-rupee orange_color"></i> <span>Flat Wise Previous Bill</span></a>
                        <ul class="collapse list-unstyled" id="flatbill2">
                           <li><a href="../bill/add_bill.php"> <span>Add Previous Bill Details</span></a></li>
                           <li><a href="../bill/display_pre_bill.php"> <span>View Previous Bill Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active"><a href="../collection/payment_upload.php"><i class="fa fa-rupee yellow_color"></i> <span>Expense Tracker</span></a></li>

                     <li>


                     <li>
                        <a href="#employee" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user orange_color"></i> <span>Employee</span></a>
                        <ul class="collapse list-unstyled" id="employee">
                           <li><a href="../emp/employee.php">> <span>Add Employee Details</span></a></li>
                           <li><a href="../emp/display_employee.php">> <span>View Employee Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active"><a href="../complains/display_complains.php"><i class="fa fa-comments yellow_color"></i> <span>Complaints</span></a></li>

                     <li class="active"><a href="../apartment/apartment_reports.php"><i class="fa fa-file orange_color"></i> <span>Reports</span></a></li>

                     <li>
                        <a href="#committee" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-users yellow_color"></i> <span>Committee</span></a>
                        <ul class="collapse list-unstyled" id="committee">
                           <li><a href="../committee/committee.php">> <span>Add Committee Details</span></a></li>
                           <li><a href="../committee/display_committee.php">> <span>View Committee Details</span></a></li>
                        </ul>
                     </li>

                     <li>
                        <a href="#notice" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-clipboard orange_color"></i> <span>Notice Board</span></a>
                        <ul class="collapse list-unstyled" id="notice">
                           <li><a href="../notice/notice.php">> <span>Add Notice Details</span></a></li>
                           <li><a href="../notice/display_notice.php">> <span>View Notice Details</span></a></li>
                        </ul>
                     </li>

                     <li>
                        <a href="#meeting" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-users yellow_color"></i> <span>Meeting Board</span></a>
                        <ul class="collapse list-unstyled" id="meeting">
                           <li><a href="../meeting/meeting.php">> <span>Add Meeting Details</span></a></li>
                           <li><a href="../meeting/display_meeting.php">> <span>View Meeting Details</span></a></li>
                        </ul>
                     </li>

                     <li>
                        <a href="#event" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-calendar orange_color"></i> <span>Event Board</span></a>
                        <ul class="collapse list-unstyled" id="event">
                           <li><a href="../event/event.php">> <span>Add Event Details</span></a></li>
                           <li><a href="../event/display_event.php">> <span>View Event Details</span></a></li>
                        </ul>
                     </li>

                     <li>
                        <a href="#acount" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-calendar yellow_color"></i> <span>Account Details</span></a>
                        <ul class="collapse list-unstyled" id="acount">
                           <li><a href="../payment_mode/payment_mode.php"> <span>Add Account Details</span></a></li>
                           <li><a href="../payment_mode/display_payment_mode.php"><span>View Account Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active"><a href="../../logout.php"><i class="fa fa-sign-out orange_color"></i> <span>Log Out</span></a></li>

                  </ul>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="index.php"><img class="img-responsive" src="../images/logo/BM22.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info" style="color:white;" id="draw">
                               <ul>

                              </ul>

                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Edit Notice Details.....!</h2>
                           </div>
                        </div>
                     </div>


                     <div class="container">


<form name="add_notice" method="post" action="update_notice.php">
<fieldset>

<!-- Text input-->
<div>
<div class="form-group">

  <input  name="id" value="<?php echo $id; ?>" placeholder=" " class="hidden"  type="text" style="margin-left:8px;" required>

  </div>
</div>


<div style="color:black;">
<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label"><span style="color:red;">*</span>&nbsp; Notice Title</label>
  <div class="col-md-4 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon" style="margin-top:8px;"><i class='fa fa-book' style='font-size:20px'></i></span>
  <input  name="notice_title" value="<?php echo $notice_title; ?>" placeholder=" " class="form-control"  type="text" style="margin-left:8px;" required>
    </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" ><span style="color:red;">*</span>&nbsp;Notice Description</label>
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon" style="margin-top:8px;"><i class='fa fa-commenting' style='font-size:20px'></i></span>
  <input name="notice_description" value="<?php echo $notice_description; ?>" placeholder=" " class="form-control"  type="text" style="margin-left:8px;" required>
    </div>
  </div>
</div>


   <div class="form-group">
  <label class="col-md-4 control-label"><span style="color:red;">*</span>&nbsp;Notice Status</label>
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon" style="margin-top:8px;"><i class='fa fa-bell' style='font-size:20px'></i></span>
  <input name="notice_status" value="<?php echo $notice_status; ?>" placeholder=" " class="form-control"  type="text" style="margin-left:8px;" required>
    </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" >Notice Created Date</label>
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon" style="margin-top:8px;"><i class='fa fa-calendar' style='font-size:20px'></i></span>
  <input name="created_date" value="<?php echo $created_date; ?>" placeholder=" " class="form-control"  type="text" style="margin-left:8px;" required>
    </div>
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4">
    <button type="submit" value="Update" class="btn btn-warning" name="update">Update <span class="glyphicon glyphicon-send"></span></button>

  </div>
</div>

</fieldset>
</form>
</div>
    </div><!-- /.container -->

      <!-- jQuery -->
      <script src="../js/jquery.min.js"></script>
      <script src="../js/popper.min.js"></script>
      <script src="../js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="../js/animate.js"></script>
      <!-- select country -->
      <script src="../js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="../js/owl.carousel.js"></script>
      <!-- chart js -->
      <script src="../js/Chart.min.js"></script>
      <script src="../js/Chart.bundle.min.js"></script>
      <script src="../js/utils.js"></script>
      <script src="../js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="../js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="../js/custom.js"></script>
      <!-- calendar file css -->
      <script src="../js/semantic.min.js"></script>

               </div></div></div></div>
   </body>
</html>