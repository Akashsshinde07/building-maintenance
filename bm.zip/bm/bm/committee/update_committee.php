<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];

	$designation = $_POST['designation'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $contact_no = $_POST['contact_no'];
    $alt_contact_no = $_POST['alt_contact_no'];
    $mail_id = $_POST['mail_id'];


        //updating the table
    $result = mysqli_query($con, "UPDATE committee SET designation='$designation', name='$name', address='$address', contact_no='$contact_no',
	alt_contact_no='$alt_contact_no', mail_id='$mail_id' WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_committee.php");
    }

?>