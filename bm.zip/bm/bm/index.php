<?php require_once("../db.php");
if(!isset($_SESSION["login_sess"]))
{
    header("location:login.php");
}
  $email=$_SESSION["login_email"];
  $findresult = mysqli_query($con, "SELECT * FROM users WHERE email= '$email'");
if($res = mysqli_fetch_array($findresult))
{
$username = $res['username'];
$fname = $res['fname'];
$lname = $res['lname'];
$email = $res['email'];
$image= $res['image'];
}
 ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Building Maintenance</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="css/custom.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
    <style>

.blue {
    background: red;

}

.news {
     position:relative;
  display: flex;
    box-shadow: inset 0 -15px 30px rgba(0,0,0,0.4), 0 5px 10px rgba(0,0,0,0.5);
       width: 95%;
    margin: 20px auto;
    overflow: hidden;
    border-radius: 4px;
    padding: 1px;
    -webkit-user-select: none;
}

.news span {
    float: left;
    color: red;

    padding: 9px;
    position: relative;
    top: 1%;
    box-shadow: inset 0 -15px 30px rgba(0,0,0,0.4);
    font: 16px 'Raleway', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -webkit-user-select: none;
    cursor: pointer;
}

.text1{

 box-shadow:none !important;
    width: 750px;
    background: white;
}
</style>
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_1">
                  <div class="sidebar-header">
                     <div class="logo_section">
                        <a href="index.php"><img class="logo_icon img-responsive" src="images/logo/BM PNG.png" alt="#" /></a>
                     </div>
                  </div>
                  <div class="sidebar_user_info">
                     <div class="icon_setting"></div>
                     <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" style="background-color:white;" src="images/logo/BM PNG.png" alt="#" /></div>
                        <div class="user_info">
                        <?php echo $username; ?>
                            <p><span class="online_animation"></span>&nbsp;Online</p>

                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar_blog_2">
                  <h4>Admin Dashboard</h4>
                  <ul class="list-unstyled components">
                     <li class="active"><a href="profile.php"><i class="fa fa-lock yellow_color"></i> <span>Change Password</span></a></li>

                     <li>
                        <a href="#apps1" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-table orange_color"></i> <span>Registration</span></a>
                        <ul class="collapse list-unstyled" id="apps1">
                           <li><a href="../registration.php"> <span>Add Admin</span></a></li>
                           <li><a href="admin_details.php"> <span>Admins Details</span></a></li>
                           <li><a href="../user_registration.php"> <span>Add User</span></a></li>
                           <li><a href="users_details.php"> <span>Users Details</span></a></li>
                           <!--li><a href="adminonly/0707.php"> <span>Delete Admin/User</span></a></li-->
                        </ul>
                     </li>

                     <li class="active"><a href="index.php"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a></li>

                     <li>
                        <a href="#apps" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-table orange_color"></i> <span>Apartment</span></a>
                        <ul class="collapse list-unstyled" id="apps">
                           <li><a href="apartment/apart.php"> <span>Add Apartment Details</span></a></li>
                           <li><a href="apartment/display_apart.php"> <span>View Apartment Details</span></a></li>
                        </ul>
                     </li>

                     <li>
                     <a href="#element" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-building-o yellow_color"></i> <span>flats</span></a>
                        <ul class="collapse list-unstyled" id="element">
                           <li><a href="flats/flat.php"> <span>Add Flat Details</span></a></li>
                           <li><a href="flats/display_flat.php"> <span>View Flat Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active">
                        <a href="#additional_page" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-wrench orange_color"></i> <span>Maintenance</span></a>
                        <ul class="collapse list-unstyled" id="additional_page">
                           <li><a href="Maintenance/maintenance.php"> <span>Add Maintenance Details</span></a></li>
                           <li><a href="Maintenance/display_maintenance.php"> <span>View Maintenance Details</span></a></li>
                        </li>
                        </ul>
                     </li>

                     <li class="active">
                        <a href="#dashboard" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user yellow_color"></i> <span>Visitors</span></a>
                        <ul class="collapse list-unstyled" id="dashboard">
                           <li><a href="Visitor/visitor.php"> <span>Add Visitor Details</span></a></li>
                           <li><a href="Visitor/display_visitor.php"> <span>View Visitor Details</span></a></li>
                        </ul>
                     </li>

                     <li>
                        <a href="#flatbill" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-rupee orange_color"></i> <span>Flat Wise Bill</span></a>
                        <ul class="collapse list-unstyled" id="flatbill">
                           <li><a href="collection/demo2.php"> <span>Add Bill Details</span></a></li>
                           <li><a href="collection/display_bill.php"> <span>View Bill Details</span></a></li>
                           <li><a href="collection/display_bill2.php"> <span>Add Cash Mode</span></a></li>
                        </ul>
                     </li>

                     <li>
                        <a href="#flatbill2" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-rupee orange_color"></i> <span>Flat Wise Previous Bill</span></a>
                        <ul class="collapse list-unstyled" id="flatbill2">
                           <li><a href="bill/add_bill.php"> <span>Add Previous Bill Details</span></a></li>
                           <li><a href="bill/display_pre_bill.php"> <span>View Previous Bill Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active"><a href="collection/payment_upload.php"><i class="fa fa-rupee yellow_color"></i> <span>Expense Tracker</span></a></li>

                     <li>
                        <a href="#employee" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user orange_color"></i> <span>Employee</span></a>
                        <ul class="collapse list-unstyled" id="employee">
                           <li><a href="emp/employee.php"> <span>Add Employee Details</span></a></li>
                           <li><a href="emp/display_employee.php"> <span>View Employee Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active"><a href="complains/display_complains.php"><i class="fa fa-comments yellow_color"></i> <span>Complaints</span></a></li>

                     <li class="active"><a href="apartment/apartment_reports.php"><i class="fa fa-file orange_color"></i> <span>Reports</span></a></li>

                     <li>
                        <a href="#committee" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-users yellow_color"></i> <span>Committee</span></a>
                        <ul class="collapse list-unstyled" id="committee">
                           <li><a href="committee/committee.php"> <span>Add Committee Details</span></a></li>
                           <li><a href="committee/display_committee.php"> <span>View Committee Details</span></a></li>
                        </ul>
                     </li>

                     <li>
                        <a href="#notice" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-clipboard orange_color"></i> <span>Notice Board</span></a>
                        <ul class="collapse list-unstyled" id="notice">
                           <li><a href="notice/notice.php"> <span>Add Notice Details</span></a></li>
                           <li><a href="notice/display_notice.php"> <span>View Notice Details</span></a></li>
                        </ul>
                     </li>

                     <li>
                        <a href="#meeting" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-users yellow_color"></i> <span>Meeting Board</span></a>
                        <ul class="collapse list-unstyled" id="meeting">
                           <li><a href="meeting/meeting.php"> <span>Add Meeting Details</span></a></li>
                           <li><a href="meeting/display_meeting.php"> <span>View Meeting Details</span></a></li>
                        </ul>
                     </li>


                     <li>
                        <a href="#event" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-calendar orange_color"></i> <span>Event Board</span></a>
                        <ul class="collapse list-unstyled" id="event">
                           <li><a href="event/event.php"> <span>Add Event Details</span></a></li>
                           <li><a href="event/display_event.php"><span>View Event Details</span></a></li>
                        </ul>
                     </li>

                     <li>
                        <a href="#acount" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-calendar yellow_color"></i> <span>Account Details</span></a>
                        <ul class="collapse list-unstyled" id="acount">
                           <li><a href="payment_mode/payment_mode.php"> <span>Add Account Details</span></a></li>
                           <li><a href="payment_mode/display_payment_mode.php"><span>View Account Details</span></a></li>
                        </ul>
                     </li>

                     <li class="active"><a href="../logout.php"><i class="fa fa-sign-out orange_color"></i> <span>Log Out</span></a></li>

                  </ul>
               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                         <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                           <a href="index.php"><img class="img-responsive" src="images/logo/BM22.png" alt="#" /></a>
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info" style="color:white;" id="draw">
                               <ul>

                              </ul>

                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">


                     <div class="news blue">
                     <span style="color:white;">HelpLine</span>
                     <span class="text1" >

                     <marquee scrollamount=4><b>
                     <a href="tel:102"><i class="fa fa-ambulance blue1_color" aria-hidden="true">&nbsp;&nbsp;Ambulance :- 102.</i>&nbsp;&nbsp;</a>
                     <a href="tel:02112224333"><i class="fa fa-bell red_color" aria-hidden="true"> Police Station :- City-02112224333.</i>&nbsp;&nbsp;</a>
                     <a href="tel:02112244172"><i class="fa fa-medkit green_color" aria-hidden="true">&nbsp;government medical college :- 02112244172.</i>&nbsp;&nbsp;</a>
                     <a href="tel:02226677555"><i class="fa fa-fire-extinguisher red_color" aria-hidden="true">&nbsp;fire brigade :- MIDC-02226677555.</i>&nbsp;&nbsp;</a>
                     <a href="tel:8329400225"><i class="fa fa-shield blue1_color" aria-hidden="true">&nbsp;Security Guard :- 8329400225</i></a>

                     <b>
                     </marquee>
                     </span>
                     </div></div>
                     </div>
                     <div class="price_table_head green_bg" style="margin-bottom:3%;">
                                                <h2>Dashboard</h2>
                                             </div>
                     <div class="row column1">


                        <div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div>
                                    <a href="flats/display_flat.php"><i class="fa fa-building-o orange_color"></i></a>
                                 </div>
                              </div>
                              <div class="counter_no">
                              <?php

                                // Create connection
                                $sqll = "SELECT  count(*) total from add_flat ";
                                if (mysqli_query($con, $sqll))
                                {
                                echo "";
                                }
                                else
                                {
                                echo "Error: " . $sqll . "<br>" . mysqli_error($con);
                                }
                                $result = mysqli_query($con, $sqll);
                                if (mysqli_num_rows($result) > 0)
                                {
                                // output data of each row
                                while($row = mysqli_fetch_assoc($result))
                                {
                                ?>
                                 <div>
                                    <p class="total_no"><?php echo $row['total']; ?></p>
                                    <p class="head_couter">Total Flats</p>

                                 </div>
                                 <?php
                                }
                                }
                                else
                                {
                                echo '0 results';
                                }
                                ?>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">


                                 <div>
                                    <a href="Maintenance/display_maintenance.php"><i class="fa fa-wrench blue1_color"></i></a>
                                 </div>
                              </div>
                              <div class="counter_no">
                              <?php

                                // Create connection
                                $sqll = "SELECT  sum(m_amount) total from maintenance ";
                                if (mysqli_query($con, $sqll))
                                {
                                echo "";
                                }
                                else
                                {
                                echo "Error: " . $sqll . "<br>" . mysqli_error($con);
                                }
                                $result = mysqli_query($con, $sqll);
                                if (mysqli_num_rows($result) > 0)
                                {
                                // output data of each row
                                while($row = mysqli_fetch_assoc($result))
                                {
                                ?>
                                 <div>
                                    <p class="total_no"><?php echo $row['total']; ?></p>
                                    <p class="head_couter">Total Maintenance</p>
                                 </div>
                                 <?php
                                }
                                }
                                else
                                {
                                echo '0 results';
                                }
                                ?>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div>
                                    <a href="collection/display_bill2.php"><i class="fa fa-money green_color"></i></a>
                                 </div>
                              </div>
                              <div class="counter_no">
                              <?php

                                // Create connection
                                $sqll = "SELECT  sum(cash_amount) total from final_bill2 ";
                                if (mysqli_query($con, $sqll))
                                {
                                echo "";
                                }
                                else
                                {
                                echo "Error: " . $sqll . "<br>" . mysqli_error($con);
                                }
                                $result = mysqli_query($con, $sqll);
                                if (mysqli_num_rows($result) > 0)
                                {
                                // output data of each row
                                while($row = mysqli_fetch_assoc($result))
                                {
                                ?>
                                 <div>
                                    <p class="total_no"><?php echo $row['total']; ?></p>
                                    <p class="head_couter">Total Cash Amount</p>

                                 </div>
                                 <?php
                                }
                                }
                                else
                                {
                                echo '0 results';
                                }
                                ?>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-6 col-lg-3">
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div>
                                    <a href="collection/display_bill2.php"><i class="fa fa-cc-visa red_color"></i></a>
                                 </div>
                              </div>
                              <div class="counter_no">
                              <?php

                                // Create connection
                                $sqll = "SELECT  sum(online_amount) total from final_bill2 ";
                                if (mysqli_query($con, $sqll))
                                {
                                echo "";
                                }
                                else
                                {
                                echo "Error: " . $sqll . "<br>" . mysqli_error($con);
                                }
                                $result = mysqli_query($con, $sqll);
                                if (mysqli_num_rows($result) > 0)
                                {
                                // output data of each row
                                while($row = mysqli_fetch_assoc($result))
                                {
                                ?>
                                 <div>
                                    <p class="total_no"><?php echo $row['total']; ?></p>
                                    <p class="head_couter">Total Online Amount</p>

                                 </div>
                                 <?php
                                }
                                }
                                else
                                {
                                echo '0 results';
                                }
                                ?>
                              </div>
                           </div>
                        </div>
                     </div>

                     <!-- graph -->
                     <!--div class="row column2 graph margin_bottom_30">
                        <div class="col-md-l2 col-lg-12">
                           <div class="white_shd full">
                              <div class="full graph_head">
                                 <div class="heading1 margin_0">
                                    <h2>Extra Area Chart</h2>
                                 </div>
                              </div>
                              <div class="full graph_revenue">
                                 <div class="row">
                                    <div class="col-md-12">
                                       <div class="content">
                                          <div class="area_chart">
                                             <canvas height="120" id="canvas"></canvas>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div-->
                     <!-- end graph -->

                     <!-- row -->
                     <div class="row column1">
                        <div class="col-md-12">
                           <div class="white_shd full margin_bottom_30">
                              <div class="full graph_head">
                                 <div class="heading1 margin_0">
                                    <h2>Activities</h2>
                                 </div>
                              </div>
                              <div class="full price_table padding_infor_info">
                                 <div class="row">

                                    <!-- column price -->
                                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                       <div class="table_price full">
                                          <div class="inner_table_price">
                                             <div class="price_table_head orange_bg">
                                                <h2>Complaints</h2>
                                             </div>
                                             <div class="price_table_inner">
                                                <?php $results = mysqli_query($con, "SELECT * FROM complains"); ?>
                                                <?php while ($row = mysqli_fetch_array($results)) { ?>
                                                <div class="cont_table_price_blog">
                                                   <p class="orange_color"><?php echo $row['created_date']; ?></p>
                                                </div>
                                                <div class="cont_table_price">
                                                    <marquee scrollamount=2 direction = "up">
                                                       <ul>
                                                          <li><a href=""><?php echo $row['complains_title']; ?></a></li>
                                                              <li><a href=""><?php echo $row['complains_Description']; ?></a></li>
                                                           </ul>
                                                    </marquee>
                                                </div>

                                                <?php } ?>
                                             </div>
                                             <div class="price_table_bottom">
                                                <div class="center"><a class="main_bt" href="complains/display_complains.php">Read More</a></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- end column price -->

                                    <!-- column price -->
                                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                       <div class="table_price full">
                                          <div class="inner_table_price">
                                             <div class="price_table_head blue1_bg">
                                                <h2>Notice</h2>
                                             </div>
                                             <div class="price_table_inner">
                                                <?php $results = mysqli_query($con, "SELECT * FROM add_notice"); ?>
                                                <?php while ($row = mysqli_fetch_array($results)) { ?>
                                                    <div class="cont_table_price_blog">
                                                       <p class="blue1_color"> <?php echo $row['created_date']; ?></p>
                                                    </div>
                                                    <div class="cont_table_price">
                                                        <marquee scrollamount=2 direction = "up">
                                                           <ul>
                                                              <li><a href=""><?php echo $row['notice_title']; ?></a></li>
                                                              <li><a href=""><?php echo $row['notice_description']; ?></a></li>
                                                           </ul>
                                                        </marquee>
                                                    </div>
                                                <?php } ?>
                                             </div>
                                             <div class="price_table_bottom">
                                                <div class="center"><a class="main_bt" href="notice/display_notice.php">Read More</a></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- end column price -->
                                    <!-- column price -->
                                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                       <div class="table_price full">
                                          <div class="inner_table_price">
                                             <div class="price_table_head green_bg">
                                                <h2>Meeting</h2>
                                             </div>
                                             <div class="price_table_inner">
                                                <?php $results = mysqli_query($con, "SELECT * FROM add_meeting"); ?>
                                                <?php while ($row = mysqli_fetch_array($results)) { ?>
                                                <div class="cont_table_price_blog">
                                                   <p class="green_color"><?php echo $row['created_date']; ?></p>
                                                </div>
                                                <div class="cont_table_price">
                                                    <marquee scrollamount=2 direction = "up">
                                                       <ul>
                                                          <li><a href=""><?php echo $row['meeting_title']; ?></a></li>
                                                              <li><a href=""><?php echo $row['meeting_description']; ?></a></li>
                                                           </ul>
                                                    </marquee>
                                                </div>
                                                <?php } ?>
                                             </div>
                                             <div class="price_table_bottom">
                                                <div class="center"><a class="main_bt" href="meeting/display_meeting.php">Read More</a></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- end column price -->
                                    <!-- column price -->
                                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                       <div class="table_price full">
                                          <div class="inner_table_price">
                                             <div class="price_table_head red_bg">
                                                <h2>Event</h2>
                                             </div>
                                             <div class="price_table_inner">
                                                <?php $results = mysqli_query($con, "SELECT * FROM add_event"); ?>
                                                <?php while ($row = mysqli_fetch_array($results)) { ?>
                                                <div class="cont_table_price_blog">
                                                   <p class="red_color"><?php echo $row['created_date']; ?></p>
                                                </div>
                                                <div class="cont_table_price">
                                                    <marquee scrollamount=2 direction = "up">
                                                       <ul>
                                                          <li><a href=""><?php echo $row['event_title']; ?></a></li>
                                                              <li><a href=""><?php echo $row['event_description']; ?></a></li>
                                                           </ul>
                                                    </marquee>
                                                </div>

                                                <?php } ?>
                                             </div>
                                             <div class="price_table_bottom">
                                                <div class="center"><a class="main_bt" href="event/display_event.php">Read More</a></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- end column price -->

                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- end row -->

                     <div class="row column4 graph">
                        <div class="col-md-6 margin_bottom_30">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">

                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-calendar"></i>
                                    <?php
                                        $date = date('d-M-yy');
                                        echo $date;
                                    ?>
                                    </h3>
                                 </div>
                                 <div class="list_cont">
                                    <p style="color:red; text-align:center;"><b>Todays Visitors</b></p>
                                 </div>
                                 <div class="task_list_main">
                                 <?php

                                // Create connection
                                $sqll = "SELECT id, v_name, v_address, relative_name, in_time, out_time FROM visitor WHERE DATE(v_date) = CURDATE();";
                                if (mysqli_query($con, $sqll))
                                {
                                echo "";
                                }
                                else
                                {
                                echo "Error: " . $sqll . "<br>" . mysqli_error($con);
                                }
                                $result = mysqli_query($con, $sqll);
                                if (mysqli_num_rows($result) > 0)
                                {
                                // output data of each row
                                while($row = mysqli_fetch_assoc($result))
                                {
                                ?>
                                    <ul class="task_list">
                                       <li><a style="color:green;">
                                       Id:
                                       <?php echo $row['id']; ?><br>
                                       Name:
                                       <?php echo $row['v_name']; ?><br>
                                       Address:
                                       <?php echo $row['v_address']; ?><br>
                                       Relative Name:
                                       <?php echo $row['relative_name']; ?><br>
                                       In Time:
                                       <strong><?php echo $row['in_time']; ?></strong>
                                       Out Time:
                                       <strong><?php echo $row['out_time']; ?></strong></li>
                                    </ul>
                                 <?php
                                }
                                }
                                else
                                {
                                echo '0 results';
                                }
                                ?>
                                 </div>
                                 <div class="read_more">
                                    <div class="center"><a class="main_bt read_bt" href="Visitor/display_visitor.php">Read More</a></div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-md-6 margin_bottom_30">
                           <div class="dash_blog">
                              <div class="dash_blog_inner">

                                 <div class="dash_head">
                                    <h3><span><i class="fa fa-calendar"></i>
                                    <?php
                                        $date = date('d-M-yy');
                                        echo $date;
                                    ?>
                                    </h3>
                                 </div>
                                 <div class="list_cont">
                                    <p style="color:green; text-align:center;"><b>Todays Maintenance</b></p>
                                 </div>
                                 <div class="task_list_main">
                                 <?php

                                // Create connection
                                $sqll = "SELECT id, m_title, m_amount, m_remark FROM maintenance WHERE DATE(m_dale) = CURDATE();";
                                if (mysqli_query($con, $sqll))
                                {
                                echo "";
                                }
                                else
                                {
                                echo "Error: " . $sqll . "<br>" . mysqli_error($con);
                                }
                                $result = mysqli_query($con, $sqll);
                                if (mysqli_num_rows($result) > 0)
                                {
                                // output data of each row
                                while($row = mysqli_fetch_assoc($result))
                                {
                                ?>
                                    <ul class="task_list">
                                       <li><a style="color:red;">
                                       Id:
                                       <?php echo $row['id']; ?><br>
                                       Title:
                                       <?php echo $row['m_title']; ?><br>
                                       Amount:
                                       <strong><?php echo $row['m_amount']; ?>-/RS</strong><br>
                                       Remark:
                                       <?php echo $row['m_remark']; ?></li>
                                    </ul>
                                 <?php
                                }
                                }
                                else
                                {
                                echo '0 results';
                                }
                                ?>
                                 </div>
                                 <div class="read_more">
                                    <div class="center"><a class="main_bt read_bt" href="Maintenance/display_maintenance.php">Read More</a></div>
                                 </div>
                              </div>
                           </div>
                        </div>


                     </div>
                  </div>
                  <!-- footer -->
                  <div class="container-fluid">
                     <div class="footer">
                        <p>Copyright © 2022 Designed by<a href="https://okispl.com/"> Om Kalyani IT Solution Pvt. Ltd.</a> All rights reserved.<br><br>
                        </p>
                     </div>
                  </div>
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="js/animate.js"></script>
      <!-- select country -->
      <script src="js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="js/owl.carousel.js"></script> 
      <!-- chart js -->
      <script src="js/Chart.min.js"></script>
      <script src="js/Chart.bundle.min.js"></script>
      <script src="js/utils.js"></script>
      <script src="js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="js/custom.js"></script>
      <script src="js/chart_custom_style1.js"></script>
   </body>
</html>