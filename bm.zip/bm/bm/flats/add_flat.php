<?php
session_start();
include('../db.php');
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$apartment_name = $_POST['apartment_name'];
$e_mail = $_POST['e_mail'];
$mob_number = $_POST['mob_number'];
$address = $_POST['address'];
$city = $_POST['city'];
$pin_code = $_POST['pin_code'];
// query

$ret=mysqli_query($con,"INSERT INTO add_flat (first_name,last_name,apartment_name,e_mail,mob_number,address,city,pin_code) VALUES
('$first_name','$last_name','$apartment_name','$e_mail','$mob_number','$address','$city','$pin_code')");

if($ret)
{
echo '<script>alert("Flat Registered Successfully.")</script>';
echo '<script>window.location.href=flat.html</script>';
}else{
echo '<script>alert("Something went wrong. Please try again.")</script>';
echo '<script>window.location.href=flat.html</script>';
}

?>