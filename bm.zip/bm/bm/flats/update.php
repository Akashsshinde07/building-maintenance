<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];

	$flat_number = $_POST['flat_number'];
	$first_name = $_POST['first_name'];
	$flat_user = $_POST['flat_user'];
	$apartment_name = $_POST['apartment_name'];
	$e_mail = $_POST['e_mail'];
	$mob_number = $_POST['mob_number'];
	$address = $_POST['address'];
	$flats = $_POST['flats'];
	$flat_number = $_POST['flat_number'];


        //updating the table
        $result = mysqli_query($con, "UPDATE add_flat SET flat_number='$flat_number', first_name='$first_name', flat_user='$flat_user', apartment_name='$apartment_name', e_mail='$e_mail',
	 mob_number='$mob_number', address='$address', flats='$flats', flat_number='$flat_number' WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_flat.php");
    }

?>