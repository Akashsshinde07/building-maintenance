   <marquee behavior="" direction="">
   <?php
    require_once("../db.php");
    // Check connection
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }

    $result = mysqli_query($con,"SELECT * FROM add_notice");

    while($row = mysqli_fetch_array($result))
      {
    echo "{$row['notice_title']}: {$row['notice_description']} ";

      }

    mysqli_close($con);
    ?>
    </marquee>

<style>

.blue {
    background: red;

}

.news {
     position:relative;
  display: flex;
    box-shadow: inset 0 -15px 30px rgba(0,0,0,0.4), 0 5px 10px rgba(0,0,0,0.5);
       width: 92%;
    margin: 20px auto;
    overflow: hidden;
    border-radius: 4px;
    padding: 1px;
    -webkit-user-select: none;
}

.news span {
    float: left;
    color: red;

    padding: 9px;
    position: relative;
    top: 1%;
    box-shadow: inset 0 -15px 30px rgba(0,0,0,0.4);
    font: 16px 'Raleway', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -webkit-user-select: none;
    cursor: pointer;
}

.text1{

 box-shadow:none !important;
    width: 750px;
    background: white;
}
</style>
<div class="news blue">
                     <span style="color:white;"> News</span>
                     <span class="text1" >


                     <marquee><b>
                       <?php

                        $result = mysqli_query($con,"SELECT * FROM add_notice INNER JOIN add_event INNER JOIN add_meeting");

                        while($row = mysqli_fetch_array($result))
                          {
                        echo "(NOTICE):- {$row['notice_title']}: {$row['notice_description']} {$row['created_date']}... (EVENTS):- {$row['event_title']} {$row['event_description']} {$row['event_status']} {$row['created_date']} ... (MEETING):- {$row['meeting_title']} {$row['meeting_description']} {$row['meeting_status']} {$row['created_date']}";

                          }

                        ?><b>
                     </marquee>
                     </span>
                     </div>