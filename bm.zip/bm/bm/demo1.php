<?php
include('../db.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Building Maintenance</title>
<style>
/* Container Border */
.container {
padding: 5px;
width:27%;
margin-left:35%;
}
form {border: 3px solid black;}

.as {border-top: 1px solid black;}
.asr {border-bottom: 1px solid black;}
.ak {border: 1px solid black;}
</style>

</head>
<body>
<?php $results = mysqli_query($con, "SELECT * FROM bill"); ?>
<?php while ($row = mysqli_fetch_array($results)) { ?>
<!--div class="container"-->
<form class="container">
    <div style="text-align:center;"  class="asr">
        <h3>Vidya Corner Super Market<br> Co-op. Housing Society Ltd.</h3>
        <h5>Plot P-15,M.I.D.C. Baramati, Dist-pune 413133<br>
        Reg No. PNA/BAI/HSG/TC/8707/2008/Dt. 10/07/2008<br>
        सुहास खाडे Mob. 7588594988 बाळासाहेब कारंडे Mob. 9822879536</h5>
    </div>

    <h4>No. &nbsp&nbsp&nbsp<?php echo $row['id']; ?>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    Date:-&nbsp&nbsp<?php echo $row['bill_date']; ?></h4>
    <h5>नाव &nbsp&nbsp:-&nbsp&nbsp <?php echo $row['name']; ?></h5>
    <h5>फ्लॅट क्रमांक &nbsp&nbsp:-&nbsp&nbsp <input class="ak" style="text-align:center;" value="<?php echo $row['invoice_no']; ?>"></h5>
    <h5>चालु रिडिंग &nbsp&nbsp:-&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['cur_read']; ?></h5>
    <h5>मागील रिडिंग &nbsp&nbsp:-&nbsp&nbsp&nbsp&nbsp <?php echo $row['pre_read']; ?></h5>

    <h5 class="as">एकूण युनीट  &nbsp&nbsp:-&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['total_unit']; ?></h5>
    <h5>दर  &nbsp&nbsp:-&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<B>x</B>&nbsp&nbsp
     <?php echo $row['price']; ?></h5>

     <h5 class="as">टोटल रक्कम &nbsp&nbsp:-&nbsp&nbsp&nbsp <?php echo $row['total_amount']; ?></h5>
     <h5>अक्षरी रु.  &nbsp&nbsp:-&nbsp&nbsp&nbsp
     <?php

    $result = mysqli_query($con, "SELECT * FROM bill");

    while($res = mysqli_fetch_array($result))
    {
        $number = $res['total_amount'];
    }

       $no = floor($number);
       $point = round($number - $no, 2) * 100;
       $hundred = null;
       $digits_1 = strlen($no);
       $i = 0;
       $str = array();
       $words = array('0' => '', '1' => 'one', '2' => 'two',
        '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
        '7' => 'seven', '8' => 'eight', '9' => 'nine',
        '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
        '13' => 'thirteen', '14' => 'fourteen',
        '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
        '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
        '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
        '60' => 'sixty', '70' => 'seventy',
        '80' => 'eighty', '90' => 'ninety');
       $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
       while ($i < $digits_1) {
         $divider = ($i == 2) ? 10 : 100;
         $number = floor($no % $divider);
         $no = floor($no / $divider);
         $i += ($divider == 10) ? 1 : 2;
         if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number] .
                " " . $digits[$counter] . $plural . " " . $hundred
                :
                $words[floor($number / 10) * 10]
                . " " . $words[$number % 10] . " "
                . $digits[$counter] . $plural . " " . $hundred;
         } else $str[] = null;
      }
      $str = array_reverse($str);
      $result = implode('', $str);
      $points = ($point) ?
        "." . $words[$point / 10] . " " .
              $words[$point = $point % 10] : '';
      echo $result . "Rupees  " . $points . " Paise";
     ?>
     </h5>
     <h5>गाळा धारकाची सही</h5>
     <h5 style="text-align:right;">Vidya Corner Super Market<br> Co-op. Housing Society Ltd.</h5>
     <h5>वरील बाकी ८दिवसात न आल्यास पुरवठा खंडीत केला जाईल.</h5>

</form>
<?php } ?>
</body>
</html>




