<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $flat_number = $_POST['flat_number'];
    $total_bill = $_POST['total_bill'];
    $cash_amount = $_POST['cash_amount'];
    $online_amount = $_POST['online_amount'];


        //updating the table
        $result = mysqli_query($con, "UPDATE final_bill2 SET total_bill='$total_bill', cash_amount='$cash_amount', online_amount='$online_amount'
         WHERE total_bill=$total_bill");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_bill2.php");
    }

?>