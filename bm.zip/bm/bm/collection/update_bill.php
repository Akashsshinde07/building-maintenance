<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $flat_number = $_POST['flat_number'];
    $pending_bill = $_POST['pending_bill'];


        //updating the table
        $result = mysqli_query($con, "UPDATE final_bill SET pending_bill='$pending_bill'
         WHERE flat_number='$flat_number'");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_bill.php");
    }

?>