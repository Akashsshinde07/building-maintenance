<?php
    include('../../db.php');
    $query ="SELECT * FROM add_flat";
    $result = $con->query($query);
    if($result->num_rows> 0){
      $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>


 <!-------first dropdown----------->
    <select name="make" id="elements">
      <option value="">-</option>
      <option data-val='m2' value="1" >1</option>
      <option data-val='m2' value="2" >2</option>
      <option data-val='m2' value="3" >3</option>
      <option data-val='m2' value="4" >4</option>
      <option data-val='m2' value="5" >5</option>
      <option data-val='m2' value="6" >6</option>

    </select>

    <!---------second dropdown---------->
    <select name="model" id="category">
      <option value="">-</option>
      <option value="370" >370</option>
    </select>


    <script>
var category = document.getElementById('category');
document.getElementById('elements').onchange = function() {
  var optionSelected = this.options[this.selectedIndex];
  if (optionSelected.textContent != '-') {
    if (optionSelected.dataset.val === 'm2') {
      category.value = '370';
    }


  } else {
    category.value = '';
  }
}
</script>



<!DOCTYPE html>
<html>
<head>
<meta charset=utf-8 />
<title>JavaScript program to calculate multiplication and division of two numbers </title>
<style type="text/css">
body {margin: 30px;}
</style>
</head>
<body>
<form>
<!-------first dropdown----------->
    <select name=" " id="firstNumber" onClick="multiplyBy()" Value="Multiply">
      <option value="">-</option>
      <option value="1" >1</option>
      <option value="2" >2</option>
      <option value="3" >3</option>
      <option value="4" >4</option>
      <option value="5" >5</option>
      <option value="6" >6</option>
      <option value="7" >7</option>
      <option value="8" >8</option>
      <option value="9" >9</option>
      <option value="10" >10</option>
      <option value="11" >11</option>
      <option value="12" >12</option>
      <option value="13" >13</option>
      <option value="14" >14</option>
      <option value="15" >15</option>
      <option value="16" >16</option>
      <option value="17" >17</option>
      <option value="18" >18</option>
      <option value="19" >19</option>
      <option value="20" >20</option>
      <option value="21" >21</option>
      <option value="22" >22</option>
      <option value="23" >23</option>
      <option value="24" >24</option>

    </select>
</form>
<p>The Result is : <br>
<span id = "result"></span>
</p>
</body>
<script>
function multiplyBy()
{
        num1 = document.getElementById("firstNumber").value;
        document.getElementById("result").innerHTML = num1 * 70 +370;
}

</script>
</html>


