<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];

    $name = $_POST['name'];
    $flat_n = $_POST['flat_n'];
    $cur_read = $_POST['cur_read'];
    $pre_read = $_POST['pre_read'];
    $total_unit = $_POST['total_unit'];
    $price = $_POST['price'];
    $bill_details = $_POST['bill_details'];


        //updating the table
        $result = mysqli_query($con, "UPDATE bill SET name='$name', flat_n='$flat_n', cur_read='$cur_read', pre_read='$pre_read'
        , total_unit='$total_unit', price='$price', bill_details='$bill_details'
         WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_bill.php");
    }

?>