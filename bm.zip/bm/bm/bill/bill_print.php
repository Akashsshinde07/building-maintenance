<?php
include('../../db.php');
if(!isset($_SESSION["login_sess"]))
{
    header("location:login.php");
}
  $email=$_SESSION["login_email"];
  $findresult = mysqli_query($con, "SELECT * FROM users WHERE email= '$email'");
  if($res = mysqli_fetch_array($findresult))
{
$username = $res['username'];
$fname = $res['fname'];
$lname = $res['lname'];
$email = $res['email'];
$image= $res['image'];
}
?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Building Maintenance</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="../images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="../css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="../style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="../css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="../css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="../css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="../css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="../css/custom.css" />
      <!-- calendar file css -->
      <link rel="stylesheet" href="../js/semantic.min.css" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <style>
      table{
    width: 100%;
    margin: 30px auto;
    border-collapse: collapse;
    text-align: center;
    color:black;
}
tr {
    border-bottom: 1px solid #cbcbcb;
}
th, td{
    border: none;
    height: 60px;
    padding: 2px;
}
tr:hover {
    background: #F5F5F5;
}

form {
    width: 45%;
    margin: 50px auto;
    text-align: left;
    padding: 20px;
    border: 1px solid #bbbbbb;
    border-radius: 5px;
}

.input-group {
    margin: 10px 0px 10px 0px;
}
.input-group label {
    display: block;
    text-align: left;
    margin: 3px;
}
.input-group input {
    height: 30px;
    width: 93%;
    padding: 5px 10px;
    font-size: 16px;
    border-radius: 5px;
    border: 1px solid gray;
}
.btn {
    padding: 10px;
    font-size: 15px;
    color: white;
    background: #5F9EA0;
    border: none;
    border-radius: 5px;
}
.edit_btn {
    text-decoration: none;
    padding: 2px 5px;
    background: #2E8B57;
    color: white;
    border-radius: 3px;
}

.del_btn {
    text-decoration: none;
    padding: 2px 5px;
    color: white;
    border-radius: 3px;
    background: red;
}
.msg {
    margin: 30px auto;
    padding: 10px;
    border-radius: 5px;
    color: #3c763d;
    background: #dff0d8;
    border: 1px solid #3c763d;
    width: 50%;
    text-align: center;
}
      </style>

<script language="javascript">
function Clickheretoprint()
{
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,";
      disp_setting+="scrollbars=yes,width=700, height=400, left=100, top=25";
  var content_vlue = document.getElementById("content").innerHTML;

  var docprint=window.open("","",disp_setting);
   docprint.document.open();
   docprint.document.write('</head><body onLoad="self.print()" style="width: 700px; font-size:11px; font-family:arial; font-weight:normal;">');
   docprint.document.write(content_vlue);
   docprint.document.close();
   docprint.focus();
}
</script>
   </head>
   <body onload="window.print();">
   <div style="margin-left:35%; margin-top:5%;">
        <h2>Bill Reports.....!</h2>
   </div>
   <?php $results = mysqli_query($con, "SELECT * FROM final_bill2"); ?>
<div style="overflow:auto">

<table class="table table-bordered" id="tblData" data-responsive="table" style="text-align: left; margin-left:2%;">
	<thead>
		<tr>
			<th width="10%"> Bill No </th>
		    <th width="10%"> Bill Date </th>
			<th width="5%">Full Name </th>
			<th width="10%"> Email ID </th>
			<th width="10%"> Flat Number </th>
			<th width="10%"> Water Unit </th>
			<th width="9%"> Additional Water Unit </th>
			<th width="10%"> Pending Bill </th>
			<th width="10%"> Maintenance Bill </th>
			<th width="10%"> Total </th>
		</tr>
	</thead>

	<?php while ($row = mysqli_fetch_array($results)) { ?>
		<tr>
			<td><?php echo $row['id']; ?></td>
			<td><?php echo $row['bill_date']; ?></td>
			<td><?php echo $row['first_name']; ?>&nbsp;<?php echo $row['last_name']; ?></td>
			<td><?php echo $row['email']; ?></td>
			<td><?php echo $row['flat_number']; ?></td>
			<td><?php echo $row['water_unit']; ?></td>
			<td><?php echo $row['additional_water_unit']; ?></td>
			<td><?php echo $row['pending_bill']; ?></td>
			<td><?php echo $row['m_amount']; ?></td>
			<td><?php echo $row['f_bill']; ?></td>

		</tr>
	<?php } ?>
</table>
</div>

   </body>
</html>