<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];

$full_name = $_POST['full_name'];
$water_bill = $_POST['water_bill'];
$water_bill_date = $_POST['water_bill_date'];
$maintenance_bill = $_POST['maintenance_bill'];
$maintenance_bill_date = $_POST['maintenance_bill_date'];


        //updating the table
        $result = mysqli_query($con, "UPDATE pre_bill SET full_name='$full_name',
        water_bill='$water_bill', water_bill_date='$water_bill_date',
	    maintenance_bill='$maintenance_bill', maintenance_bill_date='$maintenance_bill_date' WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_pre_bill.php");
    }

?>