<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];

$apart_name = $_POST['apart_name'];
$apart_address = $_POST['apart_address'];
$floor = $_POST['floor'];
$wing = $_POST['wing'];
$total_flat = $_POST['total_flat'];
$manager_name = $_POST['manager_name'];


        //updating the table
        $result = mysqli_query($con, "UPDATE apartment_details SET apart_name='$apart_name', apart_address='$apart_address',
        floor='$floor', wing='$wing', total_flat='$total_flat', manager_name='$manager_name' WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_apart.php");
    }

?>