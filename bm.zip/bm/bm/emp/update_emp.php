<?php
// including the database connection file
include_once("../../db.php");

if(isset($_POST['update']))
{
    $id = $_POST['id'];

    $emp_name = $_POST['emp_name'];
    $emp_mail = $_POST['emp_mail'];
    $emp_contact = $_POST['emp_contact'];
    $emp_pre_address = $_POST['emp_pre_address'];
    $emp_per_address = $_POST['emp_per_address'];
    $designation = $_POST['designation'];
    $joining_date = $_POST['joining_date'];
    $ending_date = $_POST['ending_date'];
    $emp_status = $_POST['emp_status'];
    $emp_pass = $_POST['emp_pass'];


        //updating the table
        $result = mysqli_query($con, "UPDATE emp SET emp_name='$emp_name', emp_mail='$emp_mail', emp_contact='$emp_contact', emp_pre_address='$emp_pre_address', emp_per_address='$emp_per_address',
         designation='$designation', joining_date='$joining_date', ending_date='$ending_date', emp_status='$emp_status', emp_pass='$emp_pass' WHERE id=$id");

        //redirectig to the display page. In our case, it is index.php
        header("Location: display_employee.php");
    }

?>