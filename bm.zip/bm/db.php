<?php
session_start();
$dbHost = 'localhost';
$dbName = 'bm';
$dbUsername = 'root';
$dbPassword = '';
$con= mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
?>
